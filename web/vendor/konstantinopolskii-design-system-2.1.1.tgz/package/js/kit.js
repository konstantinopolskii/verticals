/* kit.js — behavioural layer for the KK Agentic Design System kit.
 *
 * FROZEN as of 2.0.0. The Vue layer at packages/vue owns all behavior
 * for new work; every module below was ported 1:1 into its composables
 * (see packages/vue/sfc/composables). This file keeps serving the
 * pre-2.0 static demos and index.html exactly as shipped. Bug fixes
 * only; no new modules, no new consumers.
 *
 * Extracted from the inline <script> at the bottom of index.html in 0.7.0.
 * Plain script, no build step, no framework. Auto-inits on DOMContentLoaded.
 *
 * Public API on window.KK:
 *   KK.init()                       — idempotent, called by auto-init.
 *   KK.refresh()                    — re-scan the DOM. Each module skips
 *                                     elements it has already bound and
 *                                     binds new ones. Call this after
 *                                     injecting new decks, new doc
 *                                     sections, or new inspector cards
 *                                     into the page (SPA-style swaps).
 *                                     Global handlers are bound once;
 *                                     subsequent calls only pick up new
 *                                     iterable elements.
 *   KK.enableCommentSelectionFlow() — wires selection-to-draft +
 *                                     highlight-active observer + kebab
 *                                     actions + add-comment FAB + click-
 *                                     highlight-promote-thread. As of
 *                                     0.15.0 this runs automatically
 *                                     whenever `KK.config.comments.
 *                                     autoEnable` is true (the default)
 *                                     and a `.comment-stack` is present.
 *                                     Explicit calls remain valid and
 *                                     idempotent. Prototypes that own
 *                                     their own selection handler should
 *                                     set `comments.autoEnable: false`
 *                                     to avoid duplicate drafts.
 *   KK.extractComments()            — array of threads + anchor metadata
 *                                     + messages, walked from the live
 *                                     DOM. Always available; returns []
 *                                     when no comment-stack present.
 *   KK.copyComments()               — extractComments() + clipboard write
 *                                     of the same JSON. Returns the array
 *                                     so a consumer can also pipe it to
 *                                     a network call. As of 0.15.1 the
 *                                     kit also injects a hidden click
 *                                     target labelled "Comments" at the
 *                                     top of the inspector; clicking it
 *                                     fires this method. Devs find the
 *                                     trigger via DevTools (search for
 *                                     data-kk-action="copy-comments").
 *   KK.clearSavedComments()         — adapter.clear() + reload. Stays
 *                                     a silent no-op when persistence
 *                                     is disabled (no adapter resolved,
 *                                     no `.comment-stack`, etc).
 *
 * Config on window.KK.config.i18n (0.8.0):
 *   Consumers set their own strings BEFORE this script loads. Example:
 *     <script>
 *       window.KK = { config: { i18n: {
 *         addComment: 'Ваш комментарий',
 *         reply: 'Ответить…',
 *         deckChoose: 'Выбрать',
 *         deckChosen: 'Выбрано'
 *       } } };
 *     </script>
 *     <script src="../js/kit.js"></script>
 *   Defaults ship in English so a consumer that sets nothing still works.
 *
 * Config on window.KK.config.persist (0.14.0):
 *   Comment persistence runs by default whenever a `.comment-stack`
 *   exists. Snapshot is the stack's innerHTML; restore re-wraps doc
 *   highlights via the kit's existing kkAnchor* dataset on each thread.
 *     enabled: true  — set false on DB-backed apps that own state.
 *     key:    'kk:comments:' + location.pathname — override per page.
 *     adapter: 'localStorage' (default) | 'none' | { load, save, clear }
 *   The custom-adapter object lets a consumer route persistence into
 *   their own store. `load` returns the snapshot or null; `save` takes
 *   the snapshot; `clear` removes it. See docs/integration/comment.md
 *   for the full pattern.
 *
 * Config on window.KK.config.comments (0.15.0):
 *   Comments are a default kit affordance. Any page with `.app`
 *   containing `.book` or `#doc` gets a comment surface auto-mounted
 *   when one is missing, and the selection-to-draft flow auto-enables.
 *     enabled:    true — false disables every layer (mount + enable +
 *                        persistence on the would-be-mounted stack).
 *     autoMount:  true — false suppresses DOM injection. Consumer ships
 *                        their own `.inspector` + `.comment-stack`.
 *     autoEnable: true — false suppresses the auto-call of
 *                        enableCommentSelectionFlow. Consumer owns
 *                        selection (the prototype-alpha pattern).
 *   Pages with an existing `.comment-stack` skip auto-mount cleanly.
 *
 * Declarative html data-attribute opt-out (0.15.1):
 *   Three attributes on `<html>` provide a no-script-tag opt-out path.
 *   Map 1:1 to the JS knobs above.
 *     <html data-kk-comments="off">          → comments.enabled=false
 *     <html data-kk-comments-mount="off">    → comments.autoMount=false
 *     <html data-kk-comments-enable="off">   → comments.autoEnable=false
 *   Values: "off" / "on" / absent. Anything else is ignored.
 *   Precedence: kit defaults < html data attrs < explicit JS config.
 *   A consumer can therefore ship a global default via the html
 *   attribute and override per-page with `<script>KK.config = ...</script>`.
 *
 * Sidebar TOC auto-fill (1.10.0):
 *   The kit reads the rendered .book heading rank and writes the sidebar
 *   TOC into <nav class="sidebar__nav">. Three modes resolve from heading
 *   structure: multi-h1 (each h1 article = bold label), mixed (h2 = label,
 *   h3 = items, lead h1 article skipped), flat (h2s as flat list). Stamps
 *   ids on book__section + h2/h3 direct children. Hand-authored ids win.
 *   Per-element opt-out: <nav class="sidebar__nav" data-nav="manual">
 *   short-circuits the generator and leaves hand-curated content alone.
 *   See docs/integration/sidebar-nav.md for the full pattern.
 *
 * Auto-init covers: scroll-spy, narrow-view toggle, column reveal,
 * inspector card stack, comment kebab menus, 3D card stack deck.
 *
 * Events (0.13.0):
 *   kk:comment — CustomEvent dispatched on .comment-stack, bubbles.
 *                Fires only when the consumer has called
 *                enableCommentSelectionFlow, except for approve / archive
 *                which fire from any kebab menu whenever the thread is
 *                present. Detail per action:
 *                  { action: 'new',     threadId, messageId, anchorQuote,
 *                    anchorPrefix, anchorSuffix, cluster, sectionSlug,
 *                    text }
 *                  { action: 'reply',   threadId, messageId, text }
 *                  { action: 'edit',    threadId, messageId, text }
 *                  { action: 'delete',  threadId, messageId, threadRemoved }
 *                  { action: 'approve', threadId, messageId, replacementText,
 *                    anchorQuote, anchorPrefix, anchorSuffix, cluster,
 *                    sectionSlug }
 *                  { action: 'archive', threadId, threadRemoved }
 *                Every message carries data-message-id (generated by kit
 *                or pre-set by the server's initial render). Consumers
 *                listen once, branch on action, persist to their own
 *                backend, and maintain a local messageId → server id
 *                map. Kit does not know about authentication or server
 *                ids. Approve is available when the thread's last list
 *                message carries data-author-role="agent" (consumer sets
 *                this at render time). See docs/integration/comment.md
 *                for the full pattern + Flask / Next.js / Rails snippets.
 */
(function (global) {
  'use strict';

  // Preserve any KK object the consumer set before we loaded. Their
  // config wins; our defaults fill the gaps. Same pattern as every
  // config-merge kit that ships a default dictionary.
  var existing = global.KK || {};
  var KK = { version: '0.16.0', initialized: false };
  Object.keys(existing).forEach(function (k) { KK[k] = existing[k]; });
  KK.config = KK.config || {};
  KK.config.i18n = Object.assign({
    addComment: 'Add a comment',
    reply: 'Reply…',
    deckChoose: 'Choose',
    deckChosen: 'Chosen'
  }, KK.config.i18n || {});
  KK.config.persist = Object.assign({
    enabled: true,
    key: 'kk:comments:' + (typeof location !== 'undefined' ? location.pathname : '/'),
    adapter: 'localStorage'
  }, KK.config.persist || {});
  // Read the html data-attribute opt-outs (0.15.1) into a middle layer
  // between kit defaults and the consumer's explicit JS config. Same
  // precedence convention as every other config namespace: defaults
  // first, then declarative inherited values, then explicit overrides.
  KK.config.comments = Object.assign({
    enabled: true,
    autoMount: true,
    autoEnable: true
  }, readCommentsDataAttributes(), KK.config.comments || {});

  function readCommentsDataAttributes() {
    if (typeof document === 'undefined' || !document.documentElement) return {};
    var d = document.documentElement.dataset || {};
    function map(v) {
      if (v === 'off') return false;
      if (v === 'on')  return true;
      return undefined;
    }
    var out = {};
    var e = map(d.kkComments);        if (e !== undefined) out.enabled    = e;
    var m = map(d.kkCommentsMount);   if (m !== undefined) out.autoMount  = m;
    var a = map(d.kkCommentsEnable);  if (a !== undefined) out.autoEnable = a;
    return out;
  }

  // Minimal HTML-attribute escape. Used when injecting user-provided
  // i18n strings into innerHTML attribute contexts. textContent paths
  // do not need this.
  function attrEscape(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/</g, '&lt;');
  }

  // Slug helper. Lowercased, ASCII-only, hyphenated. Stamps ids on
  // every book__section + every direct h2 / h3 child so the auto-nav
  // generator (and the URL hash for shared deep links) has a target
  // for each navigable heading. Replaces the inline copy that lived
  // in index.html before 1.10.0.
  function slugify(text) {
    return (text || '')
      .toLowerCase()
      .replace(/[–—]/g, '-')
      .replace(/[^a-z0-9\s-]/g, '')
      .trim()
      .replace(/\s+/g, '-');
  }

  // Module-level sentinels. Each auto-init module sets its flag the
  // first time it binds global handlers. Subsequent calls (via
  // KK.refresh) skip re-binding but still pick up new iterable
  // elements (new sections for scroll-spy, new decks for the deck
  // module, new cards for the inspector stack via delegation).
  var bound = {
    scrollSpy: false,
    narrowView: false,
    columnReveal: false,
    inspectorStack: false,
    commentMenus: false,
    commentApi: false,
    commentPersistence: false,
    commentMount: false,
    commentAutoEnable: false,
    commentSecret: false,
    modal: false,
    dropdown: false,
    tabs: false,
    tooltip: false,
    toast: false,
    pagination: false
  };
  var scrollSpyObserver = null;

  // ================================================================
  // glideScroll — rAF tween of an element's scrollTop. The kit's one
  // smooth-scroll path. Native scrollTo({behavior:'smooth'}) is out:
  // two columns gliding in the same frame (sidebar chasing the active
  // group while the book jumps to a section) cancel each other in
  // Chromium, and CSS scroll-behavior fights JS-driven animation on
  // the same element tree. One rAF per element; a newer glide on the
  // same element supersedes the running one.
  // ================================================================
  var glideIds = (typeof WeakMap !== 'undefined') ? new WeakMap() : null;
  function glideScroll(el, target, duration) {
    var startTop = el.scrollTop;
    var distance = target - startTop;
    if (Math.abs(distance) < 1) return;
    var startTime = performance.now();
    var myId = (glideIds && glideIds.get(el) || 0) + 1;
    if (glideIds) glideIds.set(el, myId);
    function step(now) {
      if (glideIds && glideIds.get(el) !== myId) return;
      var elapsed = now - startTime;
      var progress = Math.min(elapsed / duration, 1);
      var eased = 1 - Math.pow(1 - progress, 3);
      el.scrollTop = startTop + distance * eased;
      if (progress < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  // ================================================================
  // Scroll-spy — sidebar indicator tracks the visible section in .book
  //
  // Refresh-friendly: on re-entry, observes any new .book__section
  // since the last init. IntersectionObserver.observe is idempotent
  // for already-observed elements. Nav links and sections are queried
  // live on each callback so SPA-style content swaps (new sections,
  // new nav links) are picked up without teardown.
  // ================================================================
  function initScrollSpy() {
    var nav = document.getElementById('toc');
    var doc = document.querySelector('.book') || document.getElementById('doc');
    if (!nav || !doc || !('IntersectionObserver' in global)) return;

    // Refresh path — observer already exists, just observe new sections.
    if (bound.scrollSpy) {
      doc.querySelectorAll('.book__section').forEach(function (s) {
        scrollSpyObserver.observe(s);
      });
      return;
    }

    var indicator = nav.querySelector('.toc__indicator');
    var firstSections = doc.querySelectorAll('.book__section');
    var firstId = firstSections[0] && firstSections[0].id;

    // The lead article (the h1 hero) is excluded from the generated nav,
    // so an id can be "best visible" while owning no nav anchor. Falling
    // back to the first anchored id keeps the indicator alive at the top
    // of the page instead of leaving the nav stateless until the reader
    // scrolls past the hero.
    function firstAnchoredId() {
      var a = nav.querySelector('a[href^="#"]');
      return a ? a.getAttribute('href').slice(1) : null;
    }
    function anchoredOrFirst(id) {
      if (id && nav.querySelector('a[href="#' + id + '"]')) return id;
      return firstAnchoredId();
    }

    function setActive(id) {
      var activeAnchor = null;
      // Live query so SPA-added nav links pick up state. The is-active
      // class lands on the anchor's parent (an <li> for items, the
      // <section class="nav-group"> for bold labels) so the existing
      // CSS cascades light up the heading and the items in the same
      // group on either kind of selection.
      nav.querySelectorAll('a[href^="#"]').forEach(function (a) {
        var key = a.getAttribute('href').slice(1);
        var on = key === id;
        var p = a.parentElement;
        if (p) p.classList.toggle('is-active', on);
        if (on) activeAnchor = a;
      });
      nav.querySelectorAll('.nav-group').forEach(function (group) {
        group.classList.toggle('is-active', !!(activeAnchor && group.contains(activeAnchor)));
      });
      moveIndicator(activeAnchor);
      scrollActiveIntoView(activeAnchor);
    }

    // Keep the active nav group inside the sidebar's viewport as the
    // reader scrolls the doc. Scroll by whole .nav-group, not by
    // individual <li>: line-by-line scrolling jitters; group-at-a-time
    // gives larger, readable jumps.
    function scrollActiveIntoView(activeEl) {
      if (!activeEl) return;
      var sidebar = activeEl.closest('.sidebar');
      if (!sidebar || getComputedStyle(sidebar).display === 'none') return;
      var group = activeEl.closest('.nav-group') || activeEl;
      var sRect = sidebar.getBoundingClientRect();
      var gRect = group.getBoundingClientRect();
      if (gRect.top >= sRect.top && gRect.bottom <= sRect.bottom) return;
      var delta;
      if (gRect.top < sRect.top || gRect.height > sRect.height) {
        delta = gRect.top - sRect.top;
      } else {
        delta = gRect.bottom - sRect.bottom;
      }
      glideScroll(sidebar, sidebar.scrollTop + delta, 320);
    }

    // Indicator measures the active anchor's own rect — tight on the
    // single row, whether that row is an item <li><a> or a bold label
    // <a class="nav-group__head"> sitting directly inside its section.
    // Measuring the parent would stretch the indicator across the whole
    // nav-group when a bold label is active.
    function moveIndicator(activeEl) {
      if (!indicator) return;
      if (!activeEl) {
        indicator.classList.remove('is-positioned');
        return;
      }
      var navRect = nav.getBoundingClientRect();
      var elRect = activeEl.getBoundingClientRect();
      var top = elRect.top - navRect.top;
      indicator.style.transform = 'translate3d(0,' + top + 'px,0)';
      indicator.style.height = elRect.height + 'px';
      if (!indicator.classList.contains('is-positioned')) {
        indicator.classList.add('is-positioned');
        // One frame later, turn on sliding transitions so the first
        // placement doesn't animate in from the origin.
        requestAnimationFrame(function () {
          indicator.classList.add('is-tracking');
        });
      }
    }

    var visible = new Set();
    // When the reader clicks a nav item we pin the indicator to that
    // target immediately and suppress scroll-spy until scrollend OR the
    // reader interrupts with wheel/touchstart. Prevents the indicator
    // chasing every section the smooth-scroll passes through.
    var scrollLocked = false;
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) visible.add(entry.target.id);
        else visible.delete(entry.target.id);
      });
      if (scrollLocked) return;
      // Live query so SPA-added sections participate in best-visible.
      var liveSections = doc.querySelectorAll('.book__section');
      var best = null;
      for (var i = 0; i < liveSections.length; i++) {
        if (visible.has(liveSections[i].id)) { best = liveSections[i].id; break; }
      }
      setActive(anchoredOrFirst(best));
    }, { root: doc, rootMargin: '0px 0px -60% 0px', threshold: 0 });

    firstSections.forEach(function (s) { observer.observe(s); });
    setActive(anchoredOrFirst(firstId));
    scrollSpyObserver = observer;

    global.addEventListener('resize', function () {
      var activeAnchor = nav.querySelector(
        '.nav-group__items li.is-active > a, .nav-group.is-active > a.nav-group__head'
      );
      if (activeAnchor) moveIndicator(activeAnchor);
    });

    nav.addEventListener('click', function (e) {
      var a = e.target.closest('a[href^="#"]');
      if (!a) return;
      var id = a.getAttribute('href').slice(1);
      var target = document.getElementById(id);
      if (!target) return;
      e.preventDefault();

      setActive(id);
      history.replaceState(null, '', '#' + id);

      scrollLocked = true;
      var release = function () {
        clearTimeout(timeoutId);
        scrollLocked = false;
        doc.removeEventListener('scrollend', release);
        doc.removeEventListener('wheel', release);
        doc.removeEventListener('touchstart', release);
        var liveSections = doc.querySelectorAll('.book__section');
        var best = null;
        for (var i = 0; i < liveSections.length; i++) {
          if (visible.has(liveSections[i].id)) { best = liveSections[i].id; break; }
        }
        setActive(anchoredOrFirst(best));
      };
      doc.addEventListener('scrollend', release, { once: true });
      doc.addEventListener('wheel', release, { once: true, passive: true });
      doc.addEventListener('touchstart', release, { once: true, passive: true });
      var timeoutId = setTimeout(release, 1500);

      // Measure against the book's own box, not offsetTop — the offset
      // chain resolves against the body and only matches by luck when
      // the book column starts at the page top.
      var top = Math.max(
        0,
        doc.scrollTop + target.getBoundingClientRect().top - doc.getBoundingClientRect().top - 20
      );
      glideScroll(doc, top, 320);
    });

    bound.scrollSpy = true;
  }

  // ================================================================
  // Narrow view — [data-view] toggle on .app
  // "doc" (default), "nav", or "inspector". CSS hides other columns
  // on phone and swaps sidebar for inspector on tablet. Desktop
  // ignores. Buttons with [data-view-target] set the view.
  // ================================================================
  function initNarrowView() {
    if (bound.narrowView) return;
    var app = document.querySelector('.app');
    if (!app) return;

    document.addEventListener('click', function (e) {
      var el = e.target.closest('[data-view-target]');
      if (!el) return;
      var target = el.getAttribute('data-view-target');
      // Tapping the active target returns to doc. Back buttons that
      // target doc explicitly do not toggle.
      var next = (app.getAttribute('data-view') === target && target !== 'doc')
        ? 'doc'
        : target;
      app.setAttribute('data-view', next);
    });

    var toc = document.getElementById('toc');
    if (toc) {
      toc.addEventListener('click', function (e) {
        if (e.target.closest('a[href^="#"]')) app.setAttribute('data-view', 'doc');
      });
    }

    bound.narrowView = true;
  }

  // ================================================================
  // Column reveal orchestrator — staggered fade + scale + slide
  // whenever a column becomes visible. Columns cascade on initial
  // paint; individual columns re-reveal when a data-view swap
  // toggles their visibility.
  // ================================================================
  function initColumnReveal() {
    if (bound.columnReveal) return;
    var app = document.querySelector('.app');
    if (!app) return;

    var COLUMNS = [
      { selector: '.book',       keyframe: 'reveal-from-below' },
      { selector: '.sidebar',   keyframe: 'reveal-from-left'  },
      { selector: '.inspector', keyframe: 'reveal-from-right' }
    ];

    var STAGGER_STEP_MS = 48;
    var STAGGER_CAP = 12;
    var COLUMN_OFFSET_MS = 160;

    function revealColumn(col, baseDelay) {
      var column = document.querySelector(col.selector);
      if (!column) return;
      if (getComputedStyle(column).display === 'none') return;

      var children = column.children;
      for (var i = 0; i < children.length; i++) {
        var el = children[i];
        var delay = baseDelay + Math.min(i, STAGGER_CAP) * STAGGER_STEP_MS;
        el.style.animation = 'none';
        void el.offsetWidth;
        el.style.animation =
          col.keyframe + ' var(--dur-long) var(--ease-swing) ' + delay + 'ms both';
      }
    }

    function isVisible(selector) {
      var el = document.querySelector(selector);
      return !!(el && getComputedStyle(el).display !== 'none');
    }

    // Track prior visibility so we only animate on hidden → visible
    // transitions. Keeps the doc from re-flashing on tablet nav toggle.
    var wasVisible = {};
    COLUMNS.forEach(function (col) {
      wasVisible[col.selector] = isVisible(col.selector);
    });

    new MutationObserver(function () {
      COLUMNS.forEach(function (col) {
        var now = isVisible(col.selector);
        if (now && !wasVisible[col.selector]) {
          revealColumn(col, 0);
        }
        wasVisible[col.selector] = now;
      });
    }).observe(app, {
      attributes: true,
      attributeFilter: ['data-view']
    });

    var cascadeIndex = 0;
    COLUMNS.forEach(function (col) {
      if (!isVisible(col.selector)) return;
      revealColumn(col, cascadeIndex * COLUMN_OFFSET_MS);
      cascadeIndex++;
    });

    bound.columnReveal = true;
  }

  // ================================================================
  // Inspector card stack — one active per group, exclusive
  // ================================================================
  function initInspectorStack() {
    if (bound.inspectorStack) return;
    var inspector = document.querySelector('.inspector');
    if (!inspector) return;

    // Inspector glides ride the shared module-level tween.
    function glideInspectorScroll(target, duration) {
      glideScroll(inspector, target, duration);
    }

    function collapseAllActive() {
      inspector.querySelectorAll('.card--interactive[data-state="active"]').forEach(function (c) {
        var collapsible = c.querySelector('.card__collapsible');
        if (collapsible) collapsible.style.transition = 'none';
        c.removeAttribute('data-state');
        if (collapsible) {
          collapsible.offsetHeight; // force layout commit
          collapsible.style.transition = '';
        }
      });
    }

    function promoteCard(card) {
      if (card.getAttribute('data-state') !== 'active') {
        collapseAllActive();
        card.setAttribute('data-state', 'active');

        // Blur any input that accidentally caught focus when the
        // minimized-label button was hidden by the CTA-swap rule.
        requestAnimationFrame(function () {
          var focused = document.activeElement;
          if (focused && card.contains(focused) &&
              focused.matches('input, textarea')) {
            focused.blur();
          }
        });
      }

      // Defer the scroll measurement one frame so any MutationObserver
      // that dismisses an empty draft has flushed before we read
      // cardRect.top.
      requestAnimationFrame(function () {
        if (!card.isConnected) return;
        var inspectorRect = inspector.getBoundingClientRect();
        var cardRect = card.getBoundingClientRect();
        var target = inspector.scrollTop + (cardRect.top - inspectorRect.top);
        glideInspectorScroll(Math.max(0, target), 320);
      });
    }

    function handleTrigger(e) {
      // Kebab menu + popover are isolated surfaces — they open/close
      // without promoting or demoting any card in the stack.
      if (e.target.closest('.comment__menu, .comment__menu-popover')) return;

      // Link cards navigate. The stack neither promotes nor glides them —
      // any scroll before a page swap reads as jank.
      if (e.target.closest('a.card, .card--link')) return;

      var card = e.target.closest('.card');
      // Empty space inside the inspector deactivates whatever is
      // promoted. focusin never lands outside a card in practice.
      if (!card) {
        if (e.type === 'click') collapseAllActive();
        return;
      }
      if (card.classList.contains('card--heading')) return;
      if (card.getAttribute('data-resolved') === 'true' ||
          card.getAttribute('data-archived') === 'true') return;

      if (card.classList.contains('card--interactive')) {
        promoteCard(card);
      } else {
        // Static card touched — demote active, glide the tapped card
        // to the top.
        collapseAllActive();
        var inspectorRect = inspector.getBoundingClientRect();
        var cardRect = card.getBoundingClientRect();
        var target = inspector.scrollTop + (cardRect.top - inspectorRect.top);
        glideInspectorScroll(Math.max(0, target), 320);
      }
    }

    inspector.addEventListener('click', handleTrigger);
    inspector.addEventListener('focusin', handleTrigger);

    bound.inspectorStack = true;
  }

  // ================================================================
  // Comment menus — kebab opens a popover, click outside closes
  // ================================================================
  function initCommentMenus() {
    if (bound.commentMenus) return;

    function closeAllMenus(except) {
      document.querySelectorAll('.comment__menu[aria-expanded="true"]').forEach(function (btn) {
        if (btn === except) return;
        btn.setAttribute('aria-expanded', 'false');
      });
    }

    // Recompute whether the Approve item should show for this thread,
    // right before the kebab opens. Approve targets the last list
    // message; the rule reads the flag through a CSS selector that
    // points at the thread's data-can-approve attribute.
    function refreshApproveAvailability(thread) {
      if (!thread) return;
      if (thread.getAttribute('data-resolved') === 'true' ||
          thread.getAttribute('data-archived') === 'true') {
        thread.removeAttribute('data-can-approve');
        return;
      }
      var list = thread.querySelector('.comment-thread__list');
      var listMsgs = list ? list.querySelectorAll(':scope > .comment-msg') : [];
      var last = listMsgs.length ? listMsgs[listMsgs.length - 1] : null;
      if (last && last.getAttribute('data-author-role') === 'agent') {
        thread.setAttribute('data-can-approve', 'true');
      } else {
        thread.removeAttribute('data-can-approve');
      }
    }

    document.addEventListener('click', function (e) {
      var btn = e.target.closest('.comment__menu');
      if (btn) {
        var wasOpen = btn.getAttribute('aria-expanded') === 'true';
        closeAllMenus(btn);
        if (!wasOpen) {
          refreshApproveAvailability(btn.closest('.comment-thread'));
        }
        btn.setAttribute('aria-expanded', wasOpen ? 'false' : 'true');
        e.stopPropagation();
        return;
      }
      if (e.target.closest('.comment__menu-popover')) {
        closeAllMenus();
        return;
      }
      closeAllMenus();
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeAllMenus();
    });

    bound.commentMenus = true;
  }

  // ================================================================
  // Deck — hover on desktop, horizontal drag on mobile
  // Adapted from the coin hero-reviews interaction.
  //
  // "Choose" / "Chosen" labels honour KK.config.i18n.deckChoose /
  // deckChosen. Consumer HTML should write the initial label to match
  // KK.config.i18n.deckChoose so the reset path stays consistent.
  // ================================================================
  function initDeck() {
    var stacks = document.querySelectorAll('.deck');
    var isMobileStack = global.matchMedia('(max-width: 1024px)').matches;

    stacks.forEach(function (wrapper) {
      if (wrapper.getAttribute('data-kk-deck-bound') === 'true') return;
      var cards = wrapper.querySelectorAll('.deck-card');
      if (cards.length === 0) return;

      var currentIndex = 0;

      function setActiveCard(index) {
        cards.forEach(function (c) { c.classList.remove('active'); });
        cards[index].classList.add('active');
        currentIndex = index;
      }

      function setChosen(card) {
        wrapper.querySelectorAll('.deck-card__select.is-chosen').forEach(function (other) {
          if (other.closest('.deck-card') === card) return;
          other.classList.remove('is-chosen');
          other.textContent = KK.config.i18n.deckChoose;
        });
        var btn = card.querySelector('.deck-card__select');
        if (!btn) return;
        if (btn.classList.contains('is-chosen')) {
          btn.classList.remove('is-chosen');
          btn.textContent = KK.config.i18n.deckChoose;
        } else {
          btn.classList.add('is-chosen');
          btn.innerHTML =
            '<span class="deck-card__check" aria-hidden="true"></span>' + attrEscape(KK.config.i18n.deckChosen);
        }
      }

      setActiveCard(0);

      if (isMobileStack) {
        // Touch handlers live on the wrapper, not on an overlay — an
        // overlay would swallow every tap and route the synthesized
        // click to a non-card target.
        wrapper.style.touchAction = 'pan-y';

        var touchStartX = 0, touchStartY = 0, lastSwitchX = 0, isHSwipe = false;

        wrapper.addEventListener('touchstart', function (e) {
          touchStartX = e.changedTouches[0].clientX;
          touchStartY = e.changedTouches[0].clientY;
          lastSwitchX = touchStartX;
          isHSwipe = false;
        }, { passive: true });

        wrapper.addEventListener('touchmove', function (e) {
          var cx = e.changedTouches[0].clientX;
          var cy = e.changedTouches[0].clientY;
          var dx = Math.abs(cx - touchStartX);
          var dy = Math.abs(cy - touchStartY);
          if (!isHSwipe && (dx > 10 || dy > 10)) isHSwipe = dx > dy;
          if (isHSwipe) {
            e.preventDefault();
            var drag = cx - lastSwitchX;
            if (Math.abs(drag) >= 30) {
              setActiveCard(drag > 0
                ? (currentIndex > 0 ? currentIndex - 1 : cards.length - 1)
                : (currentIndex + 1) % cards.length);
              lastSwitchX = cx;
            }
          }
        }, { passive: false });

        // Suppress the click that a horizontal swipe synthesizes on
        // touchend, so a swipe-to-advance doesn't accidentally toggle
        // "Chosen" on the card under the finger.
        wrapper.addEventListener('click', function (e) {
          if (isHSwipe) {
            e.stopPropagation();
            e.preventDefault();
            isHSwipe = false;
          }
        }, true);
      } else {
        cards.forEach(function (card, index) {
          card.addEventListener('mouseenter', function () {
            setActiveCard(index);
          });
        });

        // When the cursor leaves the stack, snap back to the chosen
        // card. Hovering is browsing; a choice outranks it.
        wrapper.addEventListener('mouseleave', function () {
          var chosenBtn = wrapper.querySelector('.deck-card__select.is-chosen');
          if (!chosenBtn) return;
          var chosenCard = chosenBtn.closest('.deck-card');
          var idx = Array.prototype.indexOf.call(cards, chosenCard);
          if (idx !== -1 && idx !== currentIndex) setActiveCard(idx);
        });
      }

      // Per-card click. A wrapper-level listener would resolve against
      // closest('.deck-card'), which fails when a sibling inside the
      // wrapper catches the tap.
      cards.forEach(function (card, index) {
        card.addEventListener('click', function () {
          if (!card.classList.contains('active')) {
            setActiveCard(index);
            return;
          }
          setChosen(card);
        });
      });

      wrapper.setAttribute('data-kk-deck-bound', 'true');
    });
  }

  // ================================================================
  // Comment selection flow — OPT-IN via KK.enableCommentSelectionFlow()
  //
  // Covers: selection-to-draft, draft → thread commit, highlight-active
  // MutationObserver, kebab Reply/Delete, add-comment FAB, click-
  // highlight-promote-thread.
  //
  // Opt-in because prototypes with their own localized selection
  // handlers (prototype-alpha) would conflict with the kit's English
  // draft builder. The manifesto page calls enableCommentSelectionFlow
  // to preserve its live demo.
  //
  // Note for 0.8.0: "Add a comment" and "Reply…" placeholders are
  // hardcoded English. Same i18n story as the deck labels.
  // ================================================================
  var commentFlowEnabled = false;
  function initCommentSelectionFlow() {
    if (commentFlowEnabled) return;

    var doc = document.querySelector('.book') || document.getElementById('doc');
    var inspector = document.querySelector('.inspector');
    if (!doc || !inspector) return;

    var commentStack = inspector.querySelector('.comment-stack');
    if (!commentStack) return;

    commentFlowEnabled = true;

    // Stamp every pre-rendered .comment-msg with a data-message-id so
    // the 'delete' action can address it by stable identity instead of
    // DOM position. Server-side pre-rendered messages with an existing
    // data-message-id pass through untouched.
    commentStack.querySelectorAll('.comment-msg').forEach(ensureMessageId);

    var currentAuthor = 'Konstantin Konstantinopolskii';

    function nodeInDoc(node) {
      while (node && node !== document) {
        if (node === doc) return true;
        node = node.parentNode;
      }
      return false;
    }

    // Highlight a selection as one span per text node — never one
    // wrapper around the whole range. surroundContents would promote
    // the span up to the common ancestor when the selection crosses
    // block elements, painting across padding and gaps.
    function wrapRangeAsHighlight(range) {
      var spans = [];
      var startContainer = range.startContainer;
      var startOffset    = range.startOffset;
      var endContainer   = range.endContainer;
      var endOffset      = range.endOffset;
      var root           = range.commonAncestorContainer;

      var textNodes = [];
      if (root.nodeType === Node.TEXT_NODE) {
        textNodes.push(root);
      } else {
        var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
        var n;
        while ((n = walker.nextNode())) {
          if (range.intersectsNode(n)) textNodes.push(n);
        }
      }

      textNodes.forEach(function (tn) {
        var so = (tn === startContainer) ? startOffset : 0;
        var eo = (tn === endContainer)   ? endOffset   : tn.data.length;
        if (so >= eo) return;
        var mid = tn.data.slice(so, eo);
        // Skip pure-whitespace slices — they would produce invisible
        // spans from formatting whitespace between block elements.
        if (!mid.trim()) return;
        var before = tn.data.slice(0, so);
        var after  = tn.data.slice(eo);

        var span = document.createElement('span');
        span.className = 'highlight';
        span.appendChild(document.createTextNode(mid));

        var parent = tn.parentNode;
        if (before) parent.insertBefore(document.createTextNode(before), tn);
        parent.insertBefore(span, tn);
        if (after) parent.insertBefore(document.createTextNode(after), tn);
        parent.removeChild(tn);
        spans.push(span);
      });

      return spans;
    }

    function unwrapHighlight(spans) {
      if (!spans) return;
      if (!Array.isArray(spans)) spans = [spans];
      spans.forEach(function (span) {
        if (!span || !span.parentNode) return;
        var parent = span.parentNode;
        while (span.firstChild) parent.insertBefore(span.firstChild, span);
        parent.removeChild(span);
        parent.normalize();
      });
    }

    function setAppSelection(on) {
      var app = document.querySelector('.app');
      if (!app) return;
      if (on) app.setAttribute('data-selection', 'true');
      else app.removeAttribute('data-selection');
    }

    function buildDraft(author, threadId) {
      var d = document.createElement('div');
      d.className = 'card card--interactive comment-new';
      d.dataset.threadId = threadId;
      d.innerHTML =
        '<div class="comment-new__header">' +
          '<div class="t-subtitle"></div>' +
          '<p class="t-caption comment-new__preview"></p>' +
        '</div>' +
        '<div class="card__collapsible">' +
          '<div class="card__collapsible-inner">' +
            '<label class="field comment-new__field">' +
              '<input class="t-caption field__input" type="text" placeholder="' + attrEscape(KK.config.i18n.addComment) + '" />' +
              '<span class="field__fake-caret" aria-hidden="true"></span>' +
            '</label>' +
          '</div>' +
        '</div>';
      d.querySelector('.t-subtitle').textContent = author;
      return d;
    }

    function removeDraftAndUnwrapMarks(draft) {
      if (!draft) return;
      var tid = draft.dataset.threadId;
      if (tid) {
        doc.querySelectorAll('.highlight[data-comment-id="' + tid + '"]').forEach(function (span) {
          unwrapHighlight([span]);
        });
      }
      draft.remove();
      if (!inspector.querySelector('.card.comment-new')) setAppSelection(false);
    }

    function commitDraft(draft) {
      var inp = draft.querySelector('.comment-new__field .field__input');
      if (!inp) return;
      var text = inp.value.trim();
      if (!text) return;
      var tid = draft.dataset.threadId;
      var thread = buildThread(currentAuthor, text, tid);

      // Snapshot anchor metadata before the draft's dataset is lost on
      // replaceWith. This feeds the kk:comment event consumers listen
      // for to persist the comment on their own backend.
      var anchorQuote  = draft.dataset.kkAnchorQuote  || '';
      var anchorPrefix = draft.dataset.kkAnchorPrefix || '';
      var anchorSuffix = draft.dataset.kkAnchorSuffix || '';
      var sectionSlug  = draft.dataset.kkSectionSlug  || '';
      var cluster      = draft.dataset.kkCluster      || null;

      // Mirror anchor metadata onto the thread so later actions on the
      // thread — approve in particular — can re-emit the full anchor
      // payload without a consumer-side lookup. Pre-rendered server HTML
      // can set these same attributes directly on the .comment-thread
      // and skip the draft flow entirely.
      thread.dataset.kkAnchorQuote  = anchorQuote;
      thread.dataset.kkAnchorPrefix = anchorPrefix;
      thread.dataset.kkAnchorSuffix = anchorSuffix;
      thread.dataset.kkSectionSlug  = sectionSlug;
      if (cluster) thread.dataset.kkCluster = cluster;

      // The seed message inside the brand-new thread. buildMessage has
      // already stamped its data-message-id; grab it so consumers can
      // tie their server comment id to this specific message for later
      // reply / delete events.
      var seedMsg = thread.querySelector('.comment-thread__list > .comment-msg');
      var mid = seedMsg ? seedMsg.dataset.messageId : '';

      draft.replaceWith(thread);
      // Promote via synthetic click — the stack JS flips data-state,
      // runs the blur dance, scrolls. The observer sees the new
      // data-state="active" and flips matching highlights to --active.
      requestAnimationFrame(function () { thread.click(); });
      if (!inspector.querySelector('.card.comment-new')) setAppSelection(false);

      // Emit kk:comment for consumers to persist. Bubbles to document so
      // listeners can attach anywhere. Fire-and-forget — a throwing
      // listener must not destabilize the kit's own state, so handlers
      // run inside the browser's own try/catch per the CustomEvent spec.
      commentStack.dispatchEvent(new CustomEvent('kk:comment', {
        bubbles: true,
        detail: {
          action:       'new',
          threadId:     tid,
          messageId:    mid,
          anchorQuote:  anchorQuote,
          anchorPrefix: anchorPrefix,
          anchorSuffix: anchorSuffix,
          cluster:      cluster || null,
          sectionSlug:  sectionSlug,
          text:         text
        }
      }));
    }

    // Per-message stable id. Same shape as threadId. Pre-rendered server
    // HTML may set data-message-id directly (with the server's own id);
    // ensureMessageId respects existing values so Flask / Rails / etc.
    // can ship server ids in the first paint and skip the local-to-server
    // mapping layer for seeded threads.
    function ensureMessageId(msg) {
      if (!msg.dataset.messageId) {
        msg.dataset.messageId = 'm' + Date.now() + '-' + Math.floor(Math.random() * 1000);
      }
      return msg.dataset.messageId;
    }

    function buildMessage(author, body) {
      var msg = document.createElement('div');
      msg.className = 'comment-msg';
      msg.innerHTML =
        '<div class="comment-msg__header">' +
          '<div class="t-subtitle"></div>' +
          '<button class="comment__menu" type="button" aria-label="Message actions" aria-expanded="false"><span></span></button>' +
        '</div>' +
        '<p class="t-caption"></p>' +
        '<div class="comment__menu-popover" role="menu">' +
          '<button class="comment__menu-item comment__menu-item--approve t-caption" type="button" role="menuitem">Approve</button>' +
          '<button class="comment__menu-item t-caption" type="button" role="menuitem">Edit</button>' +
          '<button class="comment__menu-item t-caption" type="button" role="menuitem">Reply</button>' +
          '<button class="comment__menu-item t-caption" type="button" role="menuitem">Archive thread</button>' +
          '<button class="comment__menu-item t-caption" type="button" role="menuitem">Delete</button>' +
        '</div>';
      msg.querySelector('.t-subtitle').textContent = author;
      msg.querySelector('.t-caption').textContent = body;
      ensureMessageId(msg);
      return msg;
    }

    // Re-render preview from the full list. 1 msg → that one;
    // 2 msgs → both, no ellipsis; 3+ → first + 3-dot ellipsis + last.
    function renderPreview(thread) {
      var list = thread.querySelector('.comment-thread__list');
      var preview = thread.querySelector('.comment-thread__preview');
      if (!list || !preview) return;
      var msgs = list.querySelectorAll(':scope > .comment-msg');
      preview.innerHTML = '';
      if (msgs.length === 0) return;
      preview.appendChild(msgs[0].cloneNode(true));
      if (msgs.length > 2) {
        var dots = document.createElement('div');
        dots.className = 'comment-thread__ellipsis';
        dots.setAttribute('aria-hidden', 'true');
        dots.innerHTML = '<span></span><span></span><span></span>';
        preview.appendChild(dots);
      }
      if (msgs.length > 1) {
        preview.appendChild(msgs[msgs.length - 1].cloneNode(true));
      }
    }

    function buildThread(author, body, threadId) {
      var thread = document.createElement('div');
      thread.className = 'card card--interactive comment-thread';
      if (threadId) thread.dataset.threadId = threadId;
      thread.innerHTML =
        '<div class="comment-thread__preview"></div>' +
        '<div class="comment-thread__edit">' +
          '<div class="comment-thread__edit-inner">' +
            '<label class="field comment-thread__edit-field">' +
              '<input class="t-caption field__input" type="text" />' +
            '</label>' +
          '</div>' +
        '</div>' +
        '<div class="card__collapsible">' +
          '<div class="card__collapsible-inner">' +
            '<div class="comment-thread__list"></div>' +
            '<label class="field comment-thread__reply">' +
              '<input class="t-caption field__input" type="text" placeholder="' + attrEscape(KK.config.i18n.reply) + '" />' +
              '<span class="field__fake-caret" aria-hidden="true"></span>' +
            '</label>' +
          '</div>' +
        '</div>';
      thread.querySelector('.comment-thread__list').appendChild(buildMessage(author, body));
      renderPreview(thread);
      return thread;
    }

    // Edit mode (0.16.0). Kebab → Edit collapses the whole thread into a
    // single field-card prefilled with the targeted message's body. Enter
    // commits the new text back to that message, exits edit. Escape and
    // any data-state demote (clicking outside the card) cancel.
    //
    // The edit slot lives at thread level (sibling of preview + collapsible)
    // so it isn't constrained by the collapsible's grid-row animation. CSS
    // hides preview + collapsible while data-editing="true" and reveals the
    // edit slot. data-state stays "active" so the field's :focus-within
    // inversion and the existing card-active stack rules keep applying.
    //
    // Threads restored from a snapshot built before 0.16.0 do not carry the
    // edit slot. ensureEditSlot lazily injects one on first edit so the
    // edit feature works against any restore.
    function ensureEditSlot(thread) {
      var slot = thread.querySelector(':scope > .comment-thread__edit');
      if (slot) return slot;
      slot = document.createElement('div');
      slot.className = 'comment-thread__edit';
      slot.innerHTML =
        '<div class="comment-thread__edit-inner">' +
          '<label class="field comment-thread__edit-field">' +
            '<input class="t-caption field__input" type="text" />' +
          '</label>' +
        '</div>';
      var collapsible = thread.querySelector(':scope > .card__collapsible');
      if (collapsible) thread.insertBefore(slot, collapsible);
      else thread.appendChild(slot);
      return slot;
    }

    function enterEditMode(thread, msg) {
      if (!thread || !msg) return;
      var bodyEl = msg.querySelector('.t-caption');
      var bodyText = bodyEl ? (bodyEl.textContent || '') : '';
      var slot = ensureEditSlot(thread);
      var input = slot.querySelector('.field__input');
      input.value = bodyText;
      // Mirror to the value attribute so a snapshot taken mid-edit
      // restores with the typed text intact (innerHTML serializes the
      // attribute, not the live DOM property).
      input.setAttribute('value', bodyText);
      thread.setAttribute('data-editing', 'true');
      thread.setAttribute('data-edit-message-id', msg.dataset.messageId || '');
      requestAnimationFrame(function () {
        input.focus();
        var len = input.value.length;
        try { input.setSelectionRange(len, len); } catch (e) {}
      });
    }

    function exitEditMode(thread, opts) {
      if (!thread) return;
      var commit = !!(opts && opts.commit);
      var slot = thread.querySelector(':scope > .comment-thread__edit');
      var input = slot && slot.querySelector('.field__input');
      var msgId = thread.getAttribute('data-edit-message-id') || '';
      thread.removeAttribute('data-editing');
      thread.removeAttribute('data-edit-message-id');

      if (!commit || !input) {
        if (input) {
          input.value = '';
          input.removeAttribute('value');
        }
        return;
      }

      var newText = input.value.trim();
      input.value = '';
      input.removeAttribute('value');

      if (!newText || !msgId) return;
      var list = thread.querySelector('.comment-thread__list');
      var msg = list && list.querySelector('.comment-msg[data-message-id="' + msgId + '"]');
      if (!msg) return;
      var bodyEl = msg.querySelector('.t-caption');
      if (bodyEl && bodyEl.textContent !== newText) {
        bodyEl.textContent = newText;
        renderPreview(thread);
        commentStack.dispatchEvent(new CustomEvent('kk:comment', {
          bubbles: true,
          detail: {
            action:    'edit',
            threadId:  thread.dataset.threadId || '',
            messageId: msgId,
            text:      newText
          }
        }));
      }
    }

    // Collect the ±20-char context around the first occurrence of `quote`
    // inside the nearest .book__section. Consumers use this for fuzzy
    // re-anchoring on the server side — quote + prefix + suffix survives
    // DOM rebuilds where numeric offsets would not. Falls back to the
    // anchor's nearest paragraph-like parent if the section is missing.
    function captureAnchorContext(quote, anchorEl) {
      if (!anchorEl || !anchorEl.closest) return { prefix: '', suffix: '' };
      var scope = anchorEl.closest('.book__section')
               || anchorEl.closest('p, dd, li')
               || anchorEl.parentNode;
      var full = (scope && scope.textContent) || '';
      var idx = full.indexOf(quote);
      if (idx === -1) return { prefix: '', suffix: '' };
      return {
        prefix: full.slice(Math.max(0, idx - 20), idx),
        suffix: full.slice(idx + quote.length, idx + quote.length + 20)
      };
    }

    function maybeOpenFromSelection() {
      var sel = global.getSelection();
      if (!sel || sel.isCollapsed) return;
      if (!nodeInDoc(sel.anchorNode) || !nodeInDoc(sel.focusNode)) return;
      var range = sel.getRangeAt(0).cloneRange();
      var quoteText = sel.toString();
      var spans = wrapRangeAsHighlight(range);
      if (!spans.length) return;

      // Re-anchor the native selection onto the freshly-wrapped spans
      // so ⌘/Ctrl+C still copies.
      var first = spans[0].firstChild;
      var last  = spans[spans.length - 1].firstChild;
      if (first && last) {
        var restored = document.createRange();
        restored.setStart(first, 0);
        restored.setEnd(last, last.data.length);
        sel.removeAllRanges();
        sel.addRange(restored);
      }

      var threadId = 'c' + Date.now() + '-' + Math.floor(Math.random() * 1000);
      spans.forEach(function (span) {
        span.setAttribute('data-comment-id', threadId);
      });

      // Capture anchor metadata on the draft for the kk:comment event
      // to emit at commit time. Stored on the draft's dataset so empty-
      // draft dismissal discards it automatically.
      var ctx = captureAnchorContext(quoteText, spans[0]);
      var sectionEl = spans[0].closest('.book__section');
      var clusterEl = spans[0].closest('[data-cluster]');

      var draft = buildDraft(currentAuthor, threadId);
      draft.dataset.kkAnchorQuote  = quoteText;
      draft.dataset.kkAnchorPrefix = ctx.prefix;
      draft.dataset.kkAnchorSuffix = ctx.suffix;
      draft.dataset.kkSectionSlug  = sectionEl ? sectionEl.id : '';
      draft.dataset.kkCluster      = clusterEl ? clusterEl.getAttribute('data-cluster') : '';

      commentStack.insertBefore(draft, commentStack.firstChild);
      setAppSelection(true);

      requestAnimationFrame(function () { draft.click(); });
    }
    doc.addEventListener('mouseup', maybeOpenFromSelection);
    doc.addEventListener('keyup', function (e) {
      if (e.shiftKey && (e.key.indexOf('Arrow') === 0 || e.key === 'Home' || e.key === 'End')) {
        maybeOpenFromSelection();
      }
    });

    commentStack.addEventListener('click', function (e) {
      var trigger = e.target.closest('[data-action="commit"]');
      if (!trigger) return;
      var draft = trigger.closest('.card.comment-new');
      if (!draft) return;
      e.stopPropagation();
      commitDraft(draft);
    });

    commentStack.addEventListener('keydown', function (e) {
      var draftInput = e.target.closest('.card.comment-new .comment-new__field .field__input');
      if (draftInput) {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          commitDraft(draftInput.closest('.card.comment-new'));
          return;
        }
        if (e.key === 'Escape') {
          e.preventDefault();
          removeDraftAndUnwrapMarks(draftInput.closest('.card.comment-new'));
          return;
        }
      }
      var editInput = e.target.closest('.comment-thread__edit .field__input');
      if (editInput) {
        var editThread = editInput.closest('.comment-thread');
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          exitEditMode(editThread, { commit: true });
          return;
        }
        if (e.key === 'Escape') {
          e.preventDefault();
          exitEditMode(editThread, { commit: false });
          return;
        }
      }

      var replyInput = e.target.closest('.comment-thread__reply .field__input');
      if (replyInput && e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        var body = replyInput.value.trim();
        if (!body) return;
        var thread = replyInput.closest('.comment-thread');
        var list = thread.querySelector('.comment-thread__list');
        var replyMsg = buildMessage(currentAuthor, body);
        list.appendChild(replyMsg);
        replyInput.value = '';
        renderPreview(thread);

        // Emit kk:comment for reply. Consumers map threadId → server
        // parent_comment_id through their own local state, then map
        // messageId → the server id the POST returns for the new reply.
        commentStack.dispatchEvent(new CustomEvent('kk:comment', {
          bubbles: true,
          detail: {
            action:    'reply',
            threadId:  thread.dataset.threadId || '',
            messageId: replyMsg.dataset.messageId,
            text:      body
          }
        }));
      }
    });

    commentStack.addEventListener('input', function (e) {
      var di = e.target.closest('.card.comment-new .comment-new__field .field__input');
      if (di) {
        var draft = di.closest('.card.comment-new');
        var preview = draft && draft.querySelector('.comment-new__preview');
        if (preview) preview.textContent = di.value;
        return;
      }
      // Sync the value attribute on the edit field so the snapshot
      // taken by the persistence MutationObserver carries the typed
      // text on reload. innerHTML serialization reads attributes, not
      // live properties; without this, a mid-edit reload comes back
      // with the field reset to the original message body.
      var ei = e.target.closest('.comment-thread__edit .field__input');
      if (ei) {
        ei.setAttribute('value', ei.value);
      }
    });

    document.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') return;
      var activeDraft = inspector.querySelector('.card.comment-new[data-state="active"]');
      if (!activeDraft) return;
      if (activeDraft.contains(document.activeElement)) return;
      e.preventDefault();
      removeDraftAndUnwrapMarks(activeDraft);
    });

    // Type-anywhere-to-focus the active comment card's input.
    document.addEventListener('keydown', function (e) {
      if (e.key.length !== 1) return;
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      var activeCard = inspector.querySelector('.comment-stack .card--interactive[data-state="active"]');
      if (!activeCard) return;
      var inp;
      if (activeCard.getAttribute('data-editing') === 'true') {
        inp = activeCard.querySelector('.comment-thread__edit .field__input');
      } else {
        inp = activeCard.querySelector('.comment-new__field .field__input, .comment-thread__reply .field__input');
      }
      if (!inp || document.activeElement === inp) return;
      var ae = document.activeElement;
      if (ae && ae.tagName) {
        var t = ae.tagName;
        if (t === 'INPUT' || t === 'TEXTAREA' || ae.isContentEditable) return;
        if (t === 'BUTTON' || t === 'A' || t === 'SELECT') return;
      }
      inp.focus();
    });

    doc.addEventListener('click', function (e) {
      var mark = e.target.closest('.highlight');
      if (!mark) return;
      var id = mark.getAttribute('data-comment-id');
      if (!id) return;
      var card = commentStack.querySelector('[data-thread-id="' + id + '"]');
      if (!card) return;
      var app = document.querySelector('.app');
      var swapped = false;
      if (app && global.matchMedia('(max-width: 768px)').matches) {
        if (app.getAttribute('data-view') !== 'inspector') {
          app.setAttribute('data-view', 'inspector');
          swapped = true;
        }
      }
      if (swapped) requestAnimationFrame(function () { card.click(); });
      else card.click();
    });

    var fabComment = document.querySelector('.fab--comment');
    if (fabComment) {
      fabComment.addEventListener('click', function () {
        var app = document.querySelector('.app');
        if (app) app.setAttribute('data-view', 'inspector');
      });
    }

    // Highlight-active observer — single source of truth for mark state.
    // Any .card--interactive[data-thread-id] with data-state="active"
    // inverts its marks; minimized drops them back to 3% overlay.
    // Empty drafts that demote get auto-dismissed.
    var observer = new MutationObserver(function (mutations) {
      mutations.forEach(function (m) {
        if (m.type !== 'attributes' || m.attributeName !== 'data-state') return;
        var card = m.target;
        if (!card.classList || !card.classList.contains('card--interactive')) return;
        var isActive = card.getAttribute('data-state') === 'active';

        // Cancel an in-flight edit when the thread leaves active state
        // (typically because the user clicked another card). No commit;
        // matches the empty-draft dismiss policy: explicit Enter is the
        // only commit path.
        if (!isActive && card.getAttribute('data-editing') === 'true') {
          exitEditMode(card, { commit: false });
        }

        // Empty-draft dismiss runs first and independent of thread id.
        // The demo ships a static .card.comment-new without a
        // data-thread-id, so a tid gate would skip the only path that
        // removes the zombie preview on demote.
        if (!isActive && card.classList.contains('comment-new')) {
          var inp = card.querySelector('.comment-new__field .field__input');
          var val = inp ? inp.value.trim() : '';
          if (!val) {
            removeDraftAndUnwrapMarks(card);
            return;
          }
          // Snapshot input value into preview in case demote missed
          // a final 'input' event.
          var preview = card.querySelector('.comment-new__preview');
          if (preview) preview.textContent = inp.value;
        }

        var tid = card.getAttribute('data-thread-id');
        if (!tid) return;

        var marks = doc.querySelectorAll('.highlight[data-comment-id="' + tid + '"]');
        marks.forEach(function (span) {
          if (isActive) span.classList.add('highlight--active');
          else span.classList.remove('highlight--active');
        });

        if (isActive && marks.length) {
          marks[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      });
    });
    observer.observe(inspector, {
      attributes: true,
      attributeFilter: ['data-state'],
      subtree: true
    });

    // Render a resolved thread in place — the approved checkmark, a
    // truncated snippet of the approved replacement, and the byline.
    // The thread stays at its slot in the stack so the reader can see
    // which anchor resolved. data-resolved drives CSS; data-state goes
    // back to minimized so an errant click does not re-expand nothing.
    function renderResolved(thread, replacementText, approvedBy) {
      var snippetMax = 40;
      var snippet = replacementText.length > snippetMax
        ? replacementText.slice(0, snippetMax - 1) + '…'
        : replacementText;
      thread.setAttribute('data-resolved', 'true');
      thread.setAttribute('data-state', 'minimized');
      var preview = thread.querySelector('.comment-thread__preview');
      if (preview) {
        preview.innerHTML =
          '<div class="comment-thread__resolved">' +
            '<span class="comment-thread__resolved-stamp t-caption" aria-hidden="true">✓</span>' +
            '<span class="comment-thread__resolved-snippet t-caption"></span>' +
            '<span class="comment-thread__resolved-byline t-caption t-muted"></span>' +
          '</div>';
        preview.querySelector('.comment-thread__resolved-snippet').textContent = snippet;
        preview.querySelector('.comment-thread__resolved-byline').textContent = approvedBy;
      }
    }

    // Kebab actions — Reply focuses the thread reply field and promotes
    // the thread; Approve collapses the thread to the resolved stamp and
    // emits the replacement payload; Archive hides the thread behind
    // data-archived (data retained); Delete removes the message (preview
    // kebab maps to first/last of the list) and empties threads remove.
    commentStack.addEventListener('click', function (e) {
      var item = e.target.closest('.comment__menu-item');
      if (!item) return;
      var thread = item.closest('.comment-thread');
      if (!thread) return;
      var msg = item.closest('.comment-msg');
      var label = (item.textContent || '').trim();

      if (label === 'Reply') {
        if (thread.getAttribute('data-state') !== 'active') {
          thread.click();
        }
        var reply = thread.querySelector('.comment-thread__reply .field__input');
        if (reply) requestAnimationFrame(function () { reply.focus(); });
        return;
      }

      if (label === 'Edit') {
        if (!msg) return;
        if (thread.getAttribute('data-state') !== 'active') {
          thread.click();
        }
        enterEditMode(thread, msg);
        return;
      }

      if (label === 'Approve') {
        // Approve takes the last list message's text and emits it as
        // the replacement for the anchored quote. Consumer uses the
        // anchor triple to locate + rewrite the quote in the doc body
        // and persist the resolution. Silent no-op if the last message
        // is not an agent reply — the popover item should already be
        // hidden by CSS when data-can-approve is absent.
        var approveList = thread.querySelector('.comment-thread__list');
        var approveMsgs = approveList
          ? approveList.querySelectorAll(':scope > .comment-msg')
          : [];
        var lastMsg = approveMsgs.length ? approveMsgs[approveMsgs.length - 1] : null;
        if (!lastMsg || lastMsg.getAttribute('data-author-role') !== 'agent') return;

        var approveBody = lastMsg.querySelector('.t-caption');
        var replacementText = approveBody ? (approveBody.textContent || '').trim() : '';
        var approvedBy = '';
        var approveHeader = lastMsg.querySelector('.comment-msg__header .t-subtitle');
        if (approveHeader) approvedBy = (approveHeader.textContent || '').trim();

        var approveThreadId  = thread.dataset.threadId  || '';
        var approveMessageId = lastMsg.dataset.messageId || '';

        renderResolved(thread, replacementText, approvedBy);

        commentStack.dispatchEvent(new CustomEvent('kk:comment', {
          bubbles: true,
          detail: {
            action:          'approve',
            threadId:        approveThreadId,
            messageId:       approveMessageId,
            replacementText: replacementText,
            anchorQuote:     thread.dataset.kkAnchorQuote  || '',
            anchorPrefix:    thread.dataset.kkAnchorPrefix || '',
            anchorSuffix:    thread.dataset.kkAnchorSuffix || '',
            cluster:         thread.dataset.kkCluster      || null,
            sectionSlug:     thread.dataset.kkSectionSlug  || ''
          }
        }));
        return;
      }

      if (label === 'Archive thread') {
        // Archive retains the thread DOM but hides it from the stack.
        // threadRemoved: false signals the consumer that the thread is
        // not deleted, just dismissed — distinct from delete's cascade
        // when the last message leaves.
        thread.setAttribute('data-archived', 'true');
        thread.setAttribute('data-state', 'minimized');
        var archivedThreadId = thread.dataset.threadId || '';
        commentStack.dispatchEvent(new CustomEvent('kk:comment', {
          bubbles: true,
          detail: {
            action:        'archive',
            threadId:      archivedThreadId,
            threadRemoved: false
          }
        }));
        return;
      }

      if (label === 'Delete') {
        if (!msg) return;
        var list = thread.querySelector('.comment-thread__list');
        var listMsgs = list.querySelectorAll(':scope > .comment-msg');

        // Resolve the preview kebab to the actual list message the user
        // targeted (preview shows the first and last of the full list).
        // Capture the messageId from the resolved list entry before it
        // leaves the DOM, so the kk:comment event can name what was
        // deleted by stable identity.
        var targetMsg = msg;
        if (msg.closest('.comment-thread__preview')) {
          var previewMsgs = thread.querySelectorAll('.comment-thread__preview > .comment-msg');
          var idx = Array.prototype.indexOf.call(previewMsgs, msg);
          if (idx === 0 && listMsgs.length) {
            targetMsg = listMsgs[0];
          } else if (idx === 1 && listMsgs.length > 1) {
            targetMsg = listMsgs[listMsgs.length - 1];
          } else {
            targetMsg = null;
          }
        }
        if (!targetMsg) return;

        var deletedThreadId  = thread.dataset.threadId || '';
        var deletedMessageId = targetMsg.dataset.messageId || '';

        targetMsg.remove();

        var remaining = list.querySelectorAll(':scope > .comment-msg');
        var threadRemoved = remaining.length === 0;
        if (threadRemoved) {
          thread.remove();
        } else {
          renderPreview(thread);
        }

        // Emit kk:comment for delete. threadRemoved signals whether the
        // consumer should treat this as a message delete (thread stays)
        // or a thread delete (last message gone, whole thread removed
        // from the DOM). Consumer picks the right server route.
        commentStack.dispatchEvent(new CustomEvent('kk:comment', {
          bubbles: true,
          detail: {
            action:        'delete',
            threadId:      deletedThreadId,
            messageId:     deletedMessageId,
            threadRemoved: threadRemoved
          }
        }));
      }
    });
  }

  // ================================================================
  // Comment API: extract + copy. Walks the live DOM at call time, so
  // it works regardless of persistence config. Each thread pairs with
  // its anchor metadata plus messages. Same shape as the kk:comment
  // event so consumers see one schema across both surfaces.
  // ================================================================
  function extractCommentsFromDom() {
    var stack = document.querySelector('.comment-stack');
    if (!stack) return [];
    var threads = stack.querySelectorAll('.comment-thread');
    var out = [];
    for (var i = 0; i < threads.length; i++) {
      var t = threads[i];
      var listMsgs = t.querySelectorAll('.comment-thread__list > .comment-msg');
      var messages = [];
      for (var j = 0; j < listMsgs.length; j++) {
        var m = listMsgs[j];
        var sub = m.querySelector('.t-subtitle');
        var body = m.querySelector('p.t-caption');
        messages.push({
          messageId: m.dataset.messageId || '',
          author:    sub  ? sub.textContent.trim()  : '',
          body:      body ? body.textContent.trim() : '',
          role:      m.getAttribute('data-author-role') || 'user'
        });
      }
      out.push({
        threadId:     t.getAttribute('data-thread-id') || '',
        resolved:     t.getAttribute('data-resolved') === 'true',
        archived:     t.getAttribute('data-archived') === 'true',
        anchorQuote:  t.dataset.kkAnchorQuote  || '',
        anchorPrefix: t.dataset.kkAnchorPrefix || '',
        anchorSuffix: t.dataset.kkAnchorSuffix || '',
        sectionSlug:  t.dataset.kkSectionSlug  || '',
        cluster:      t.dataset.kkCluster      || null,
        messages:     messages
      });
    }
    return out;
  }

  function initCommentApi() {
    if (bound.commentApi) return;
    KK.extractComments = extractCommentsFromDom;
    KK.copyComments = function () {
      var data = extractCommentsFromDom();
      var json = JSON.stringify(data, null, 2);
      if (global.navigator && navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(json);
      }
      return data;
    };
    // Default no-op. initCommentPersistence overrides with the real
    // adapter-bound implementation when persistence resolves. This way
    // `KK.clearSavedComments()` is always callable; it just does nothing
    // when there is nothing to clear.
    if (!KK.clearSavedComments) {
      KK.clearSavedComments = function () {};
    }
    bound.commentApi = true;
  }

  // ================================================================
  // Comment persistence. Default-on whenever a `.comment-stack` and a
  // doc surface (`.book` or `#doc`) coexist. Snapshot is the stack's
  // innerHTML plus a savedAt timestamp; restore re-wraps doc highlights
  // via the kit's existing kkAnchor* dataset on each thread/draft.
  //
  // Adapter resolution:
  //   'none'             — bail. DB-backed apps that own state.
  //   { load,save,clear} — custom store. All three required.
  //   anything else      — built-in localStorage adapter at config.key.
  // ================================================================
  function resolvePersistAdapter(cfg) {
    if (cfg.adapter === 'none') return null;
    if (cfg.adapter && typeof cfg.adapter === 'object') {
      var a = cfg.adapter;
      if (typeof a.load  === 'function' &&
          typeof a.save  === 'function' &&
          typeof a.clear === 'function') return a;
      return null;
    }
    var key = cfg.key;
    return {
      load: function () {
        try {
          var raw = global.localStorage && localStorage.getItem(key);
          return raw ? JSON.parse(raw) : null;
        } catch (e) { return null; }
      },
      save: function (snap) {
        try { localStorage.setItem(key, JSON.stringify(snap)); } catch (e) {}
      },
      clear: function () {
        try { localStorage.removeItem(key); } catch (e) {}
      }
    };
  }

  // Re-wrap a single quote inside the given scope. Single-text-node match
  // only — selections that crossed element boundaries on first wrap won't
  // restore as a contiguous span. The thread itself restores fine; just
  // the doc-side highlight is lost. Same trade-off as the original
  // agreement.html implementation this module generalises.
  function rewrapQuoteInScope(scope, quote, threadId) {
    if (!scope || !quote) return;
    var walker = document.createTreeWalker(scope, NodeFilter.SHOW_TEXT, null);
    var node;
    while ((node = walker.nextNode())) {
      // Skip text already inside a highlight (idempotent restore).
      if (node.parentElement && node.parentElement.closest('.highlight')) continue;
      var idx = node.data.indexOf(quote);
      if (idx < 0) continue;
      var mid = node.splitText(idx);
      mid.splitText(quote.length);
      var span = document.createElement('span');
      span.className = 'highlight';
      span.setAttribute('data-comment-id', threadId);
      span.appendChild(document.createTextNode(mid.data));
      mid.parentNode.replaceChild(span, mid);
      return;
    }
  }

  function rewrapAllHighlights(doc, stack) {
    var threads = stack.querySelectorAll(
      '.comment-thread[data-thread-id], .card.comment-new[data-thread-id]'
    );
    for (var i = 0; i < threads.length; i++) {
      var t = threads[i];
      var id = t.getAttribute('data-thread-id');
      var quote = t.dataset.kkAnchorQuote || '';
      if (!id || !quote) continue;
      var sectionId = t.dataset.kkSectionSlug || '';
      var scope = sectionId ? document.getElementById(sectionId) : null;
      if (!scope) scope = doc;
      rewrapQuoteInScope(scope, quote, id);
    }
  }

  function initCommentPersistence() {
    if (bound.commentPersistence) return;

    var cfg = KK.config.persist;
    if (!cfg || cfg.enabled === false) return;

    var adapter = resolvePersistAdapter(cfg);
    if (!adapter) return;

    var doc = document.querySelector('.book') || document.getElementById('doc');
    var stack = document.querySelector('.comment-stack');
    if (!doc || !stack) return;

    bound.commentPersistence = true;

    // Restore. Accept any snapshot with a string `stack` field — v is
    // optional and assumed 1 when absent, so pre-0.14.0 inline-script
    // snapshots (e.g., the explee agreement) restore on first load.
    var snapshot = null;
    try { snapshot = adapter.load(); } catch (e) { snapshot = null; }
    var compatibleSchema = !snapshot || snapshot.v == null || snapshot.v === 1;
    if (snapshot && compatibleSchema && typeof snapshot.stack === 'string') {
      stack.innerHTML = snapshot.stack;
      rewrapAllHighlights(doc, stack);
    }

    // md.js rebuilds `.book` after we restored. The first-pass rewrap
    // ran against an empty doc, so the highlights never landed. Re-run
    // each time md.js fires kk:md-rendered. Idempotent: rewrap skips
    // text already inside an existing .highlight, so a second pass
    // through stable HTML is a no-op.
    document.addEventListener('kk:md-rendered', function () {
      rewrapAllHighlights(doc, stack);
    });

    // Save observer. 200 ms debounce; characterData true so mid-typing
    // drafts persist between reloads.
    var saveTimer = null;
    function scheduleSave() {
      if (saveTimer) clearTimeout(saveTimer);
      saveTimer = setTimeout(function () {
        adapter.save({
          v: 1,
          savedAt: Date.now(),
          stack: stack.innerHTML
        });
      }, 200);
    }
    new MutationObserver(scheduleSave).observe(stack, {
      childList: true,
      subtree: true,
      characterData: true
    });

    KK.clearSavedComments = function () {
      adapter.clear();
      location.reload();
    };
  }

  // ================================================================
  // Comment auto-mount. Comments are a default kit affordance: any
  // page with `.app` containing `.book` or `#doc` gets a `.comment-
  // stack` injected when one is missing, plus an `.inspector` to host
  // it if the consumer did not ship one. Pages without `.app` skip
  // the injection. The kit will not add columns to layouts that did
  // not opt into the three-column shell.
  //
  // Idempotent. Bails when `comments.enabled` or `comments.autoMount`
  // is explicitly false, or when an existing `.comment-stack` is
  // already present.
  // ================================================================
  function autoMountCommentSurface() {
    if (bound.commentMount) return;
    var cfg = KK.config.comments;
    if (!cfg || cfg.enabled === false || cfg.autoMount === false) return;

    var app = document.querySelector('.app');
    if (!app) return;
    var doc = app.querySelector('.book') || app.querySelector('#doc');
    if (!doc) return;
    if (document.querySelector('.comment-stack')) {
      bound.commentMount = true;
      return;
    }

    var inspector = app.querySelector('.inspector');
    if (!inspector) {
      inspector = document.createElement('aside');
      inspector.className = 'inspector';
      inspector.setAttribute('aria-label', 'Comments');
      app.appendChild(inspector);
    }
    var stack = document.createElement('div');
    stack.className = 'comment-stack';
    inspector.appendChild(stack);
    bound.commentMount = true;
  }

  // Auto-call initCommentSelectionFlow when criteria hold. Decoupled
  // from the explicit KK.enableCommentSelectionFlow API so existing
  // pages that call enable directly remain idempotent (the flow's
  // own commentFlowEnabled sentinel short-circuits the second call).
  function autoEnableCommentSelectionFlow() {
    if (bound.commentAutoEnable) return;
    var cfg = KK.config.comments;
    if (!cfg || cfg.enabled === false || cfg.autoEnable === false) return;
    if (!document.querySelector('.comment-stack')) return;
    if (!document.querySelector('.book') && !document.getElementById('doc')) return;
    bound.commentAutoEnable = true;
    initCommentSelectionFlow();
  }

  // ================================================================
  // Hidden copy-comments target (0.15.1).
  //
  // Injects an aria-hidden, opacity-0 <h2 data-kk-action="copy-comments">
  // labelled "Comments" at the top of any inspector that hosts a
  // .comment-stack. Click the top ~24 px strip → KK.copyComments()
  // fires. Devs find the trigger by searching the DOM for the
  // data-kk-action attribute or the literal "Comments" heading text.
  // ================================================================
  function initCommentSecretCopy() {
    if (bound.commentSecret) return;
    var stack = document.querySelector('.comment-stack');
    if (!stack) return;
    var inspector = stack.closest('.inspector');
    if (!inspector) return;

    if (!inspector.querySelector('[data-kk-action="copy-comments"]')) {
      var heading = document.createElement('h2');
      heading.textContent = 'Comments';
      heading.setAttribute('aria-hidden', 'true');
      heading.setAttribute('data-kk-action', 'copy-comments');
      heading.style.cssText =
        'position:absolute;top:0;left:0;right:0;' +
        'height:24px;margin:0;padding:0;' +
        'opacity:0;font-size:0;line-height:0;' +
        'cursor:default;z-index:1;';
      if (getComputedStyle(inspector).position === 'static') {
        inspector.style.position = 'relative';
      }
      inspector.insertBefore(heading, inspector.firstChild);
    }

    document.addEventListener('click', function (e) {
      if (!e.target.closest('[data-kk-action="copy-comments"]')) return;
      e.preventDefault();
      e.stopPropagation();
      if (typeof KK.copyComments === 'function') KK.copyComments();
    });

    bound.commentSecret = true;
  }

  // ================================================================
  // Sidebar TOC generator (1.10.0). Builds the sidebar table of
  // contents from the rendered .book DOM. Source of truth: the
  // heading rank inside each top-level book__section. Replaces the
  // hand-curated <section class="nav-group"> blocks that every
  // consuming page used to copy.
  //
  // Rule (locked at 2026-04-27-auto-sidebar-nav stage 1):
  //   ≥2 top-level book__section whose primary heading is h1
  //                   → bold label = each h1; items = h2-rooted
  //                     nested book__sections under each h1.
  //   1 such section (or 0), ≥1 top-level book__section that
  //   has an h3 direct child anywhere in .book
  //                   → bold label = each non-lead section's h2;
  //                     items = its h3 direct children.
  //                     h2 with no h3 children stands alone as label.
  //   otherwise        → flat list of each non-lead section's h2,
  //                     no group label.
  //
  // Lead-article exclusion (single-h1 mode only): the article whose
  // primary heading is h1 is the page intro, not a navigable section.
  //
  // Opt-out: <nav class="sidebar__nav" data-nav="manual"> short-
  // circuits the pass. Hand-curated content stays untouched.
  //
  // Idempotent. Runs from KK.init() (DOMContentLoaded) and from
  // KK.refresh() (kk:md-rendered, SPA swaps). Each pass clears every
  // child of the nav except .toc__indicator and rebuilds.
  // ================================================================
  function getPrimaryHeading(section) {
    return section.querySelector('h1, h2, h3');
  }

  // Heading text minus any post-<br> sub-label. The kit's static-body
  // pages sometimes split a heading like
  //   <h2>Switching it off<br /><span class="t-display--medium">For DB-backed apps</span></h2>
  // The bold sub-label is visual rhythm; the nav and the slug want only
  // the primary text. Walks child nodes until the first BR and joins
  // their textContent.
  function headingLabel(h) {
    if (!h) return '';
    var label = '';
    for (var i = 0; i < h.childNodes.length; i++) {
      var n = h.childNodes[i];
      if (n.nodeName === 'BR') break;
      label += (n.textContent || '');
    }
    return label.trim();
  }

  function stampHeadingIds(book) {
    var allSections = book.querySelectorAll('article.book__section');
    Array.prototype.forEach.call(allSections, function (section) {
      if (!section.id) {
        var h = getPrimaryHeading(section);
        if (h) {
          var id = slugify(headingLabel(h));
          if (id) section.id = id;
        }
      }
      // Stamp ids on direct heading children so the nav can target
      // them with #hash links. Skips already-stamped headings so
      // hand-authored ids win.
      section.querySelectorAll(':scope > h2, :scope > h3').forEach(function (h) {
        if (!h.id) {
          var id = slugify(headingLabel(h));
          if (id) h.id = id;
        }
      });
    });
  }

  function buildSidebarToc() {
    var nav = document.getElementById('toc');
    if (!nav) return;
    if (nav.getAttribute('data-nav') === 'manual') return;

    var book = document.querySelector('.book') || document.getElementById('doc');
    if (!book) return;

    stampHeadingIds(book);

    var topSections = Array.prototype.slice.call(
      book.querySelectorAll(':scope > article.book__section')
    );
    if (topSections.length === 0) return;

    function topHeadingTag(section) {
      var h = getPrimaryHeading(section);
      return h ? h.tagName : null;
    }

    var h1Sections = topSections.filter(function (s) {
      return topHeadingTag(s) === 'H1';
    });
    var multiH1 = h1Sections.length >= 2;

    var anyH3 = topSections.some(function (s) {
      return s.querySelector(':scope > h3') !== null;
    });

    // Clear nav, preserving the indicator span.
    var indicator = nav.querySelector('.toc__indicator');
    Array.prototype.slice.call(nav.children).forEach(function (child) {
      if (child !== indicator) nav.removeChild(child);
    });
    if (!indicator) {
      indicator = document.createElement('span');
      indicator.className = 'toc__indicator';
      indicator.setAttribute('aria-hidden', 'true');
      nav.appendChild(indicator);
    }

    function makeGroup(headLabel, headHref, items) {
      var section = document.createElement('section');
      section.className = 'nav-group';
      if (headLabel && headHref) {
        var head = document.createElement('a');
        head.className = 't-subtitle nav-group__head';
        head.setAttribute('href', '#' + headHref);
        head.textContent = headLabel;
        section.appendChild(head);
      }
      if (items && items.length) {
        var ul = document.createElement('ul');
        ul.className = 'nav-group__items';
        items.forEach(function (it) {
          if (!it.label || !it.href) return;
          var li = document.createElement('li');
          li.className = 't-caption';
          var a = document.createElement('a');
          a.setAttribute('href', '#' + it.href);
          a.textContent = it.label;
          li.appendChild(a);
          ul.appendChild(li);
        });
        if (ul.children.length) section.appendChild(ul);
      }
      return section;
    }

    if (multiH1) {
      topSections.forEach(function (s) {
        var primary = getPrimaryHeading(s);
        if (!primary || primary.tagName !== 'H1') return;
        var label = headingLabel(primary);
        var href = s.id;
        if (!href || !label) return;

        // Items: nested book__sections whose own primary heading is h2.
        // md.js wraps each h2-rooted region inside the outer article;
        // the outer article's h1-rooted intro is one of those nested
        // sections, with primary = h1 — skip it as the lead.
        var nested = Array.prototype.slice.call(
          s.querySelectorAll(':scope article.book__section')
        );
        var items = nested.map(function (inner) {
          var h = getPrimaryHeading(inner);
          if (!h || h.tagName !== 'H2') return null;
          return { label: headingLabel(h), href: inner.id };
        }).filter(Boolean);

        nav.appendChild(makeGroup(label, href, items));
      });
    } else if (anyH3) {
      topSections.forEach(function (s) {
        var primary = getPrimaryHeading(s);
        if (!primary) return;
        if (primary.tagName === 'H1') return; // lead article

        var label = headingLabel(primary);
        var href = s.id;
        if (!href || !label) return;

        var h3s = Array.prototype.slice.call(s.querySelectorAll(':scope > h3'));
        var items = h3s.map(function (h3) {
          return { label: headingLabel(h3), href: h3.id };
        }).filter(function (it) { return it.label && it.href; });

        nav.appendChild(makeGroup(label, href, items));
      });
    } else {
      var items = topSections.map(function (s) {
        var primary = getPrimaryHeading(s);
        if (!primary) return null;
        if (primary.tagName === 'H1') return null; // lead article
        return { label: headingLabel(primary), href: s.id };
      }).filter(function (it) { return it && it.label && it.href; });

      if (items.length) {
        nav.appendChild(makeGroup(null, null, items));
      }
    }
  }

  // ================================================================
  // EXPANSION 1.16.0 — interactive modules (modal, dropdown, tabs,
  // tooltip, toast, pagination). Same delegated, idempotent,
  // KK.refresh-safe shape as the comment/deck modules above.
  // ================================================================
  // ================================================================
  // Modal — centered dialog over a scrim. Trigger lives in page markup
  // as [data-modal-open="ID"]; the dialog is the element #ID. Opening
  // moves focus into the dialog and traps Tab within it; closing
  // restores focus to the opener. Scrim click, any [data-modal-close],
  // and Escape all close. Body scroll locks while any modal is open.
  //
  // Idempotent + KK.refresh-safe: the document listeners bind once
  // (guarded by bound.modal), and they resolve [data-modal-open] /
  // [data-modal-close] live, so modals injected later need no
  // re-binding. Mirrors initCommentMenus (outside-click + Escape).
  //
  // Integrator wiring:
  //   1. Add `modal: false` to the `bound` sentinel object.
  //   2. Call initModal() inside KK.init() and KK.refresh().
  // ================================================================
  var modalOpeners = (typeof WeakMap !== 'undefined') ? new WeakMap() : null;
  function initModal() {
    if (bound.modal) return;

    // Visible, focusable controls inside a dialog, in DOM order.
    function focusables(dialog) {
      return Array.prototype.filter.call(
        dialog.querySelectorAll(
          'a[href], button:not([disabled]), input:not([disabled]), ' +
          'select:not([disabled]), textarea:not([disabled]), ' +
          '[tabindex]:not([tabindex="-1"])'
        ),
        function (el) {
          return el.offsetWidth || el.offsetHeight || el.getClientRects().length;
        }
      );
    }

    function anyOpen() {
      return !!document.querySelector('.modal[data-state="open"]');
    }

    KK.openModal = function (id) {
      var modal = document.getElementById(id);
      if (!modal || !modal.classList.contains('modal')) return;
      if (modal.getAttribute('data-state') === 'open') return;

      // Portal to <body> so the fixed scrim and dialog resolve against
      // the viewport, not a transformed ancestor. The column-reveal
      // orchestrator leaves an identity transform on every
      // .book__section (animation-fill-mode: both), which establishes a
      // containing block that would otherwise trap the scrim to the
      // reading column. Idempotent: a re-opened modal already sits in body.
      if (modal.parentNode !== document.body) document.body.appendChild(modal);

      // Remember the opener so focus can return to it on close.
      var opener = document.activeElement;
      if (opener && modalOpeners) modalOpeners.set(modal, opener);

      modal.setAttribute('data-state', 'open');
      modal.setAttribute('aria-hidden', 'false');
      document.documentElement.style.overflow = 'hidden'; // body scroll lock

      var dialog = modal.querySelector('.modal__dialog');
      if (!dialog) return;
      var f = focusables(dialog);
      if (f.length) {
        f[0].focus();
      } else {
        if (!dialog.hasAttribute('tabindex')) dialog.setAttribute('tabindex', '-1');
        dialog.focus();
      }
    };

    KK.closeModal = function (id) {
      var modal = document.getElementById(id);
      if (!modal || modal.getAttribute('data-state') !== 'open') return;

      modal.setAttribute('data-state', 'closed');
      modal.setAttribute('aria-hidden', 'true');
      if (!anyOpen()) document.documentElement.style.overflow = '';

      var opener = modalOpeners && modalOpeners.get(modal);
      if (opener && typeof opener.focus === 'function' && opener.isConnected) {
        opener.focus();
      }
      if (modalOpeners) modalOpeners.delete(modal);
    };

    // Open + close triggers on one delegated click listener.
    document.addEventListener('click', function (e) {
      var opener = e.target.closest('[data-modal-open]');
      if (opener && opener.getAttribute('data-modal-open')) {
        e.preventDefault();
        KK.openModal(opener.getAttribute('data-modal-open'));
        return;
      }
      var closer = e.target.closest('[data-modal-close]');
      if (closer) {
        var modal = closer.closest('.modal');
        if (modal && modal.id) KK.closeModal(modal.id);
      }
    });

    // Escape closes the open modal; Tab is trapped within its dialog.
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        var openEsc = document.querySelector('.modal[data-state="open"]');
        if (openEsc && openEsc.id) {
          e.preventDefault();
          KK.closeModal(openEsc.id);
        }
        return;
      }
      if (e.key !== 'Tab') return;

      var openModal = document.querySelector('.modal[data-state="open"]');
      if (!openModal) return;
      var dialog = openModal.querySelector('.modal__dialog');
      if (!dialog) return;

      var f = focusables(dialog);
      if (!f.length) { e.preventDefault(); return; }
      var first = f[0];
      var last = f[f.length - 1];
      var active = document.activeElement;

      // Pull any stray focus back inside, then wrap at both ends.
      if (!dialog.contains(active)) {
        e.preventDefault();
        first.focus();
      } else if (e.shiftKey && active === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && active === last) {
        e.preventDefault();
        first.focus();
      }
    });

    bound.modal = true;
  }

  // ================================================================
  // Dropdown — menu-button popover. The trigger toggles a role="menu"
  // popover; outside-click and Escape close it (mirrors initCommentMenus).
  // Up/Down give roving focus over the menuitems, Home/End jump to the
  // ends; Enter/Space activate natively because each row is a real
  // <button role="menuitem">. Choosing a row dispatches
  // `kk:dropdown-select` on the .dropdown and returns focus to the
  // trigger. Idempotent; safe under KK.refresh().
  //
  // Integrator: add `dropdown: false` to the `bound` sentinel object and
  // call initDropdown() from both KK.init() and KK.refresh().
  // ================================================================
  function initDropdown() {
    if (bound.dropdown) return;

    function items(dd) {
      return Array.prototype.slice.call(dd.querySelectorAll('.dropdown__item'));
    }

    function closeAll(except) {
      document
        .querySelectorAll('.dropdown[data-dropdown] .dropdown__popover[data-state="open"]')
        .forEach(function (pop) {
          var dd = pop.closest('[data-dropdown]');
          if (dd === except) return;
          pop.setAttribute('data-state', 'closed');
          var trigger = dd.querySelector('.dropdown__trigger');
          if (trigger) trigger.setAttribute('aria-expanded', 'false');
        });
    }

    function openDropdown(dd) {
      var pop = dd.querySelector('.dropdown__popover');
      var trigger = dd.querySelector('.dropdown__trigger');
      if (!pop) return;
      pop.setAttribute('data-state', 'open');
      if (trigger) trigger.setAttribute('aria-expanded', 'true');
      var first = items(dd)[0];
      if (first) first.focus();
    }

    function focusTrigger(dd) {
      var trigger = dd.querySelector('.dropdown__trigger');
      if (trigger) trigger.focus();
    }

    function activate(dd, item) {
      var text = (item.textContent || '').trim();
      var value = item.getAttribute('data-value');
      dd.dispatchEvent(new CustomEvent('kk:dropdown-select', {
        bubbles: true,
        detail: {
          label: text,
          value: value === null ? text : value,
          index: items(dd).indexOf(item)
        }
      }));
      closeAll(null);
      focusTrigger(dd);
    }

    document.addEventListener('click', function (e) {
      var trigger = e.target.closest('.dropdown__trigger');
      if (trigger) {
        var dd = trigger.closest('[data-dropdown]');
        var wasOpen = trigger.getAttribute('aria-expanded') === 'true';
        closeAll(null);
        if (!wasOpen) openDropdown(dd);
        e.stopPropagation();
        return;
      }
      var item = e.target.closest('.dropdown__item');
      if (item) {
        var owner = item.closest('[data-dropdown]');
        if (owner) activate(owner, item);
        return;
      }
      closeAll(null);
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        var openPop = document.querySelector('.dropdown[data-dropdown] .dropdown__popover[data-state="open"]');
        if (openPop) {
          var dd = openPop.closest('[data-dropdown]');
          closeAll(null);
          focusTrigger(dd);
        }
        return;
      }
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp' || e.key === 'Home' || e.key === 'End') {
        var pop = e.target.closest('.dropdown__popover[data-state="open"]');
        if (!pop) return;
        var list = items(pop.closest('[data-dropdown]'));
        if (!list.length) return;
        e.preventDefault();
        var i = list.indexOf(document.activeElement);
        var next;
        if (e.key === 'Home') next = 0;
        else if (e.key === 'End') next = list.length - 1;
        else if (e.key === 'ArrowDown') next = i < 0 ? 0 : (i + 1) % list.length;
        else next = i <= 0 ? list.length - 1 : i - 1;
        list[next].focus();
      }
    });

    bound.dropdown = true;
  }

  // ================================================================
  // Tabs — underlined tab strip over stacked panels.
  //
  // INTEGRATOR WIRING (paste inside the KK IIFE in js/kit.js):
  //   1. Add a sentinel to the `bound` object:  tabs: false
  //   2. Call initTabs() from KK.init() AND KK.refresh().
  //
  // Fully delegated (two document-level listeners, bound once), so it
  // is idempotent and picks up any `.tabs` injected after load without
  // re-binding — same shape as initCommentMenus. No public API: the DOM
  // state (aria-selected + panel [hidden]) is the whole contract.
  // Automatic-activation model: moving focus with the arrow keys also
  // selects the tab, so the visible panel always follows the focus ring.
  // ================================================================
  function initTabs() {
    if (bound.tabs) return;

    // Select `tab`, deselect its siblings, and show the matching panel.
    // Pass focus=true for keyboard-driven moves so the focus ring rides
    // the selection; click keeps the pointer's own focus behaviour.
    function selectTab(tab, focus) {
      var list = tab.closest('.tabs__list');
      if (!list) return;
      list.querySelectorAll('.tabs__tab').forEach(function (t) {
        var isTarget = t === tab;
        t.setAttribute('aria-selected', isTarget ? 'true' : 'false');
        var panel = document.getElementById(t.getAttribute('aria-controls'));
        if (!panel) return;
        if (isTarget) panel.removeAttribute('hidden');
        else panel.setAttribute('hidden', '');
      });
      if (focus) tab.focus();
    }

    document.addEventListener('click', function (e) {
      var tab = e.target.closest('.tabs__tab');
      if (!tab) return;
      selectTab(tab, false);
    });

    document.addEventListener('keydown', function (e) {
      var tab = e.target.closest ? e.target.closest('.tabs__tab') : null;
      if (!tab) return;
      var list = tab.closest('.tabs__list');
      if (!list) return;
      var tabs = Array.prototype.slice.call(list.querySelectorAll('.tabs__tab'));
      var i = tabs.indexOf(tab);
      if (i === -1) return;

      var next = null;
      switch (e.key) {
        case 'ArrowRight':
        case 'ArrowDown':
          next = tabs[(i + 1) % tabs.length];
          break;
        case 'ArrowLeft':
        case 'ArrowUp':
          next = tabs[(i - 1 + tabs.length) % tabs.length];
          break;
        case 'Home':
          next = tabs[0];
          break;
        case 'End':
          next = tabs[tabs.length - 1];
          break;
        default:
          return;
      }
      e.preventDefault();
      selectTab(next, true);
    });

    bound.tabs = true;
  }

  // ================================================================
  // Tooltip — hint bubble on an inline trigger
  //
  // Integrator: paste initTooltip into the js/kit.js IIFE, add
  //   tooltip: false
  // to the `bound` sentinel object, and call initTooltip() from both
  // KK.init() and KK.refresh() (alongside initDeck / initCommentMenus).
  // No public KK.* API — the component is declarative markup only.
  //
  // Delegated at the document level so it is idempotent and picks up any
  // tooltip added later (KK.refresh needs no per-instance rebind): one
  // pointer pair, one focus pair, one Escape handler cover every
  // [data-tooltip] on the page. Mirrors the single-listener shape of
  // initCommentMenus.
  // ================================================================
  function initTooltip() {
    if (bound.tooltip) return;

    function bubbleFor(tip) {
      return tip ? tip.querySelector('.tooltip__bubble') : null;
    }
    function openTip(tip) {
      var bubble = bubbleFor(tip);
      if (bubble) bubble.setAttribute('data-state', 'open');
    }
    function closeTip(tip) {
      var bubble = bubbleFor(tip);
      if (bubble) bubble.setAttribute('data-state', 'closed');
    }
    function closeAll(except) {
      document.querySelectorAll('.tooltip__bubble[data-state="open"]').forEach(function (bubble) {
        if (except && except.contains(bubble)) return;
        bubble.setAttribute('data-state', 'closed');
      });
    }

    // Pointer. mouseover/mouseout bubble (mouseenter/leave do not), so a
    // single delegated pair reaches every trigger. The bubble itself is
    // pointer-events:none, so it never fires these — leaving the trigger
    // always closes.
    document.addEventListener('mouseover', function (e) {
      var tip = e.target.closest('.tooltip[data-tooltip]');
      if (!tip) return;
      var bubble = bubbleFor(tip);
      if (bubble && bubble.getAttribute('data-state') === 'open') return;
      closeAll(tip);
      openTip(tip);
    });
    document.addEventListener('mouseout', function (e) {
      var tip = e.target.closest('.tooltip[data-tooltip]');
      if (!tip) return;
      // Ignore moves that stay inside the same tooltip.
      if (e.relatedTarget && tip.contains(e.relatedTarget)) return;
      closeTip(tip);
    });

    // Keyboard / assistive tech. focusin/focusout bubble to document.
    document.addEventListener('focusin', function (e) {
      var tip = e.target.closest('.tooltip[data-tooltip]');
      if (!tip) return;
      closeAll(tip);
      openTip(tip);
    });
    document.addEventListener('focusout', function (e) {
      var tip = e.target.closest('.tooltip[data-tooltip]');
      if (!tip) return;
      if (e.relatedTarget && tip.contains(e.relatedTarget)) return;
      closeTip(tip);
    });

    // Escape closes any open bubble.
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeAll();
    });

    bound.tooltip = true;
  }

  // ================================================================
  // Toast — inverted status message, bottom-center singleton stack.
  //
  // KK.toast(text, opts) is the imperative entry: find or build the
  // stack, append a toast, play it in, auto-dismiss after
  // opts.duration (default 4000ms; 0 keeps it until dismissed), and
  // wire the dismiss × plus an optional action button. initToast()
  // delegates close/action clicks so a toast printed by the server (or
  // rendered by <KToast>) dismisses without the imperative path.
  //
  // Manifesto: the toast is a black/inverted surface, so the soft FAB
  // shadow is permitted material. No status colors — one ink surface,
  // meaning lives in the words.
  //
  // Add `toast: false` to the `bound` sentinel map; it also runs safe
  // if the flag is absent (undefined is falsy on first pass).
  // ================================================================
  function toastStackEl() {
    var stack = document.querySelector('.toast-stack[data-toast-stack]');
    if (stack) return stack;
    stack = document.createElement('div');
    stack.className = 'toast-stack';
    stack.setAttribute('data-toast-stack', '');
    stack.setAttribute('aria-live', 'polite');
    stack.setAttribute('aria-atomic', 'false');
    document.body.appendChild(stack);
    return stack;
  }

  function dismissToast(toast) {
    if (!toast || toast.getAttribute('data-state') === 'closed') return;
    toast.setAttribute('data-state', 'closed');
    var removed = false;
    function remove() {
      if (removed) return;
      removed = true;
      if (toast.parentNode) toast.parentNode.removeChild(toast);
    }
    toast.addEventListener('transitionend', remove, { once: true });
    // Fallback: if no transition fires (reduced-motion collapses the
    // token to ~0), tear down anyway so the node never lingers.
    global.setTimeout(remove, 400);
  }

  KK.toast = function (text, opts) {
    opts = opts || {};
    var stack = toastStackEl();

    var toast = document.createElement('div');
    toast.className = 'toast';
    toast.setAttribute('role', 'status');
    toast.setAttribute('data-state', 'closed');

    var span = document.createElement('span');
    span.className = 'toast__text';
    span.textContent = text == null ? '' : String(text);
    toast.appendChild(span);

    if (opts.action) {
      var action = document.createElement('button');
      action.className = 'toast__action';
      action.type = 'button';
      action.textContent = String(opts.action);
      action.addEventListener('click', function () {
        if (typeof opts.onAction === 'function') opts.onAction();
        dismissToast(toast);
      });
      toast.appendChild(action);
    }

    var close = document.createElement('button');
    close.className = 'toast__close';
    close.type = 'button';
    close.setAttribute('aria-label', 'Dismiss');
    close.textContent = '×';
    close.addEventListener('click', function () { dismissToast(toast); });
    toast.appendChild(close);

    stack.appendChild(toast);

    // Force a reflow so the from-state paints before we flip to open —
    // otherwise the enter transition is skipped and the toast pops in.
    void toast.offsetWidth;
    toast.setAttribute('data-state', 'open');

    var duration = typeof opts.duration === 'number' ? opts.duration : 4000;
    if (duration > 0) {
      global.setTimeout(function () { dismissToast(toast); }, duration);
    }

    return toast;
  };

  // Server-rendered toasts (or <KToast> markup): delegate dismissal for
  // the close × and the action button. Idempotent and refresh-safe —
  // one document-level listener, bound once. Imperative toasts also
  // carry direct listeners; dismissToast guards against double-fire.
  function initToast() {
    if (bound.toast) return;
    document.addEventListener('click', function (e) {
      var hit = e.target.closest('.toast__close, .toast__action');
      if (!hit) return;
      dismissToast(hit.closest('.toast'));
    });
    bound.toast = true;
  }

  // ================================================================
  // Pagination — optimistic aria-current + a page-change event.
  //
  // Paste this function inside the js/kit.js IIFE, next to initDeck /
  // initCommentMenus. It reuses the module-level `bound` guard object and
  // runs off one delegated document listener, so it is idempotent and
  // safe under KK.refresh().
  //
  // Presentational component: the page buttons are consumer-wired. This
  // module only moves aria-current to the resolved page (optimistically)
  // and fires a bubbling `kk:page-change` CustomEvent carrying
  // { page, previous } so the consumer can fetch the next slice. Edge
  // buttons resolve to the current page number +/- 1; when an edge steps
  // past the visible window the numerals are left as-is and the consumer
  // re-renders. Disabled edges are ignored. No KK.* method — the event is
  // the whole contract.
  //
  // Wire the call into KK.init() and KK.refresh() alongside the other
  // init* modules:
  //     initPagination();
  // ================================================================
  function initPagination() {
    if (bound.pagination) return;

    function pageNum(btn) {
      return btn ? parseInt(btn.textContent, 10) : null;
    }

    document.addEventListener('click', function (e) {
      var control = e.target.closest('.pagination__page, .pagination__edge');
      if (!control || control.disabled) return;
      var nav = control.closest('.pagination');
      if (!nav) return;

      var pages = Array.prototype.slice.call(nav.querySelectorAll('.pagination__page'));
      var currentBtn = nav.querySelector('.pagination__page[aria-current="page"]');
      var previous = pageNum(currentBtn);

      var targetNum;
      if (control.classList.contains('pagination__edge')) {
        if (previous == null) return;
        targetNum = control.getAttribute('data-dir') === 'prev' ? previous - 1 : previous + 1;
      } else {
        targetNum = pageNum(control);
      }
      if (targetNum == null || targetNum === previous) return;

      // Optimistic: move aria-current to the matching visible numeral if
      // the window still holds one. When an edge steps past the window the
      // consumer re-renders, so leaving the marker where it is is correct.
      var match = pages.filter(function (b) { return pageNum(b) === targetNum; })[0];
      if (match) {
        pages.forEach(function (b) { b.removeAttribute('aria-current'); });
        match.setAttribute('aria-current', 'page');
      }

      nav.dispatchEvent(new CustomEvent('kk:page-change', {
        bubbles: true,
        detail: { page: targetNum, previous: previous },
      }));
    });

    bound.pagination = true;
  }

  // ================================================================
  // Public API
  // ================================================================
  KK.init = function () {
    if (KK.initialized) return;
    // Build the sidebar TOC before scroll-spy initializes so the
    // observer's first setActive pass finds the new anchors. On
    // markdown-body pages the .book is empty at DOMContentLoaded; the
    // generator no-ops and runs again on kk:md-rendered.
    buildSidebarToc();
    initScrollSpy();
    initNarrowView();
    // Mount runs BEFORE columnReveal so an injected `.inspector`
    // participates in the staggered reveal cascade.
    autoMountCommentSurface();
    initColumnReveal();
    initInspectorStack();
    initCommentMenus();
    initCommentApi();
    initCommentPersistence();
    autoEnableCommentSelectionFlow();
    initCommentSecretCopy();
    initDeck();
    initModal();
    initDropdown();
    initTabs();
    initTooltip();
    initToast();
    initPagination();
    KK.initialized = true;
  };

  // Re-scan the DOM for new iterable elements and wire them up. Safe
  // to call any time — modules skip work they have already done.
  // Global listeners bound once (on .inspector, .app, document, window,
  // #toc) keep working through DOM mutations because they are delegated
  // or watch stable ancestors. Per-instance bindings (each .deck wrapper,
  // each observed .book__section) get picked up by this call.
  //
  // Call after injecting new decks, new doc sections, new inspector
  // cards, new nav items, or new comment threads into the page. Safe to
  // over-call; there is no teardown and no double-binding.
  KK.refresh = function () {
    buildSidebarToc();
    initScrollSpy();
    initNarrowView();
    autoMountCommentSurface();
    initColumnReveal();
    initInspectorStack();
    initCommentMenus();
    initCommentApi();
    initCommentPersistence();
    autoEnableCommentSelectionFlow();
    initCommentSecretCopy();
    initDeck();
    initModal();
    initDropdown();
    initTabs();
    initTooltip();
    initToast();
    initPagination();
  };

  KK.enableCommentSelectionFlow = function () {
    initCommentSelectionFlow();
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', KK.init);
  } else {
    KK.init();
  }

  // md.js dispatches kk:md-rendered after every markdown article in
  // the page finishes loading. The kit's auto-nav, scroll-spy, and
  // section-id stamper all need to re-run against the freshly-rendered
  // DOM. Bound once at module load so consumers no longer need a per-
  // page post-render hook.
  document.addEventListener('kk:md-rendered', KK.refresh);

  global.KK = KK;
})(window);
