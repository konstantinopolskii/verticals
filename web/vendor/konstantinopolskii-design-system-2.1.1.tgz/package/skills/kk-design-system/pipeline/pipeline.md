# The pipeline

Eight stages. Three phases. Eleven role skills. Do not skip stages inside a phase. Do not reorder them. Gates are either human approval, a peer-agent pass, or a rubric-gated verdict.

This file describes the `kk-design-system` pipeline that ships UI prototypes. A sibling pipeline `kk-charter-system` (orchestrator at `../../kk-charter-system/`) ships strategic charters with the same eight-stage shape and five shared roles. The full cross-pipeline roster lives in §Role roster below.

Entry point matches scope. A new page walks all eight stages. A copy tweak enters at stage 3b against an existing block. Kit refactoring enters at stage 5 in DS-engineer mode. Nothing forces the full walk on work that does not need it.

The point: AI agents draft most of our work. Without gates they produce gray mush, invent components, and ship the first plausible draft. The pipeline enforces breadth at the think phase, question-driven fidelity at the design phase, cold-read audits and strict rubric at the build phase. Each stage writes its own documentation artifact so retros never replay the conversation.

## Phase 1. Think

### Stage 1. Analyst

- **Role skill:** `kk-role-analyst`
- **Model:** Sonnet. **Character:** Margaret Hamilton.
- **Input:** User brief plus referenced materials (files, transcripts, tickets).
- **Output:** Decomposed brief covering users, job stories (`context + motivation = step → value`), priority scenarios, open questions.
- **Canon load:** `manifesto.md` (philosophy, job stories).
- **Gate:** Human approves the brief. Every open question stamped.
- **Self-doc:** `documentation/<session>/01-analyst.md`

The analyst pushes back. If the brief has holes, they surface here. No pixels yet.

### Stage 2. Design Director

- **Role skill:** `kk-role-design-director`
- **Model:** Opus. **Character:** Charlotte Perriand.
- **Input:** Approved brief from stage 1.
- **Output, round one:** Five or more directions, each with a one-line intent, primary signal, guardrails, expected kit surface.
- **Output, round two (after user picks):** Direction document carrying the aligned direction, named pattern blocks (N per session), exceptions register, rejected-directions archive, alignment transcript.
- **Canon load:** `manifesto.md` (full file, including §Components covering patterns, card, typography), `tokens.json`, `patterns/*`.
- **Gate 2a:** Human picks one direction. Others archive.
- **Gate 2b:** Human stamps pattern blocks + any exceptions. Round-two direction document locked.
- **Self-doc:** `documentation/<session>/02-design-director.md`

Breadth on round one, commitment on round two. The pattern-block naming is the handoff contract. Downstream designers spawn one per block.

## Phase 2. Design

Per-pattern, question-driven. N pattern blocks means N parallel designer tracks. Each pattern walks a three-substage loop.

### Stage 3a. Fresh-eyes pre-designer (N parallel, one per pattern)

- **Role skill:** `kk-role-fresh-eyes-jobstory` (pre-designer mode)
- **Model:** Haiku. **Character:** Steve Jobs.
- **Input:** Direction doc's pattern block + analyst job story.
- **Output:** Question list per pattern, what to look for first, what to try, what this is for, unclarities, 0.2-second self-evidence check.
- **Canon load:** `pipeline.md` §Dumb-reviewer character + §Fidelity contract only.
- **Gate:** None. Feeds stage 3b.
- **Self-doc:** `documentation/<session>/03a-fresh-eyes-pre-<pattern-slug>.md`

Naive user POV. Zero design context. Reading `manifesto.md § Components` would break the cold-read contract.

### Stage 3b. Designer (N parallel, one per pattern)

- **Role skill:** `kk-role-designer`
- **Model:** Sonnet. **Character:** Hella Jongerius.
- **Input:** Direction doc + 3a question list for this pattern.
- **Output:** Per-pattern hand-off carrying question-to-answer map, states (rest/hover/focus/active/disabled/loading/empty/error), interaction variants, edge cases, example content, UI copy drafts, kit-inventory check.
- **Canon load:** `manifesto.md` (full file, including §Components), `tokens.json`, `voice.md`, `patterns/*`.
- **Gate:** Stage 3c pass. Unanswered 3a questions fail and re-dispatch to this stage.
- **Self-doc:** `documentation/<session>/03b-designer-<pattern-slug>.md`

Single track. Strict kit inventory unless the direction doc's §Exceptions carries a user-stamped override for this pattern. UI copy drafts ship downstream. There is no separate copywriter.

### Stage 3c. Fresh-eyes post-designer (N parallel, one per pattern)

- **Role skill:** `kk-role-fresh-eyes-jobstory` (post-designer mode)
- **Model:** Haiku. **Character:** Steve Jobs.
- **Input:** Designer hand-off (03b) + original question list (03a).
- **Output:** Pass/fail per question. Gap list on fail.
- **Canon load:** `pipeline.md` §Dumb-reviewer character + §Fidelity contract only.
- **Gate:** All patterns must pass 3c before stage 4 runs. Fails return to 3b with the gap list.
- **Self-doc:** `documentation/<session>/03c-fresh-eyes-post-<pattern-slug>.md`

## Phase 3. Build

### Stage 4. DS Manager

- **Role skill:** `kk-role-ds-manager`
- **Model:** Sonnet. **Character:** Muriel Cooper.
- **Input:** Direction doc + every 03b hand-off.
- **Output:** Per-block component map (kit class + variant + attribute + kit-demo section), build-order task split, kit-demo references, inventory check.
- **Canon load:** `manifesto.md § Components`, `tokens.json`, `patterns/*`, the kit demo `index.html`.
- **Gate:** Inventory check passes, or halts back to 3b with a named pattern.
- **Self-doc:** `documentation/<session>/04-ds-manager.md`

Catalogue, not draw. Copy briefs out of scope. Designers own UI copy.

### Stage 5. Design Engineer

- **Role skill:** `kk-role-design-engineer`
- **Model:** Sonnet. **Character:** Sara Soueidan.
- **Input:** DS Manager component map + task split + every 03b hand-off + direction doc.
- **Output:** Prototype built piece by piece, saved to disk as each piece lands. Vue pages from `packages/vue` components (static HTML generated via `packages/vue/ssg.mjs` when the deliverable is a static page). Designer UI copy drafts verbatim; dummy text flagged where drafts are missing.
- **Canon load:** `manifesto.md` (full file, including §Foundations and §Components), `tokens.json`, `patterns/*`, `voice.md` §AI tells.
- **Gate:** Stages 6a + 6b run in parallel on the built files. Then stage 7.
- **Self-doc:** `documentation/<session>/05-design-engineer.md`

Piece-by-piece means the human can peek mid-build. Short feedback loop. No placeholder-comment-for-copywriter convention. Copywriter stage is gone.

### Stage 6a. Consistency, jobstory

- **Role skill:** `kk-role-consistency-jobstory`
- **Model:** Haiku. **Character:** Steve Jobs.
- **Input:** Built prototype files only. Zero upstream context.
- **Output:** Per-block cold read, what is on screen, what looks doable, what this is for, what is great, what could be better.
- **Canon load:** `pipeline.md` §Dumb-reviewer character only.
- **Gate:** No direct gate. Output feeds stage 7.
- **Self-doc:** `documentation/<session>/06a-consistency-jobstory.md`

Cold means cold. Reading the brief or direction doc would pollute the read. The reviewer's guesses are the signal.

### Stage 6b. Consistency, DS

- **Role skill:** `kk-role-consistency-ds`
- **Model:** Haiku. **Character:** Dieter Rams.
- **Input:** Built prototype files + `manifesto.md § Components` + `tokens.json`. No brief, no direction, no hand-off.
- **Output:** Per-block strict audit across class resolution, token compliance, off-grid spacing, pattern-language drift.
- **Canon load:** `manifesto.md` (full file, including §Foundations and §Components), `tokens.json`.
- **Gate:** No direct gate. Output feeds stage 7.
- **Self-doc:** `documentation/<session>/06b-consistency-ds.md`

Dumb-about-layout, strict-about-inventory.

### Stage 6c. Voice

- **Role skill:** `kk-role-voice-reviewer`
- **Model:** Haiku. **Character:** George Orwell.
- **Input:** Built prototype files + `voice.md`. No brief, no direction, no hand-off.
- **Output:** Per-block voice audit across AI-tells, button-label discipline, empty-state shape, error shape, sentence case, em-dash and italics rules, muted and light-weight rules. Evidence carries file:line + string + rule.
- **Canon load:** `voice.md` full, `manifesto.md` §Philosophy and §Why this exists.
- **Gate:** No direct gate. Output feeds stage 7.
- **Self-doc:** `documentation/<session>/06c-voice.md`

Cold-reads strings against canon. Does not rewrite; names the defect.

### Stage 7. Meta-reviewer

- **Role skill:** `kk-role-meta-reviewer`
- **Model:** Opus. **Character:** Anna Wintour.
- **Input:** Full chain. 01 + 02 + every 03b + 05 + 06a + 06b + 06c + the built prototype.
- **Output:** Rubric-gated issue list. PASS or FAIL verdict with per-item evidence.
- **Canon load:** `manifesto.md`, `voice.md`, `pipeline.md` §Meta-reviewer rubric + §Reiterate protocol + §Fidelity contract.
- **Gate:** PASS ships. FAIL routes user to §Reiterate protocol.
- **Self-doc:** `documentation/<session>/07-meta-reviewer.md`

Rejects "it's fine" replies. A rubric item is either answered with evidence (file:line citation) or left open. Open items fail the build until the user acts.

## Meta. Retro

- **Role skill:** `kk-role-meta-retro`
- **Model:** Opus. **Character:** Joan Didion.
- **Input:** All session documentation in `documentation/<session>/*`.
- **Output:** `proposals/<date>-retro.md`. Proposed updates to `manifesto.md`, `pipeline.md`, `voice.md`, `tokens.json`. Never edits canon directly.
- **Trigger:** On-demand only. User calls the retro when something feels off.
- **Gate:** Human accepts or rejects each proposal. Accepted proposals route to `kk-ds-maintainer`.

## Protocols

### Fidelity contract

High-fidelity output earns its label by answering questions a naive user of the job story would ask. Stages 3a → 3b → 3c run the loop:

1. **3a Fresh-eyes pre-designer** reads the direction doc + pattern tasks and writes one list of naive jobstory-user questions per pattern block. Zero design context, strictly user POV.
2. **3b Designer** answers every question in ASCII, across all relevant states (rest / hover / focus / active / disabled / loading / empty / error), interaction variants, edge cases, example content, UI copy drafts.
3. **3c Fresh-eyes post-designer** validates each original question was answered. Unanswered questions fail the stage. Returns to 3b with the gap list.

The contract: every user-facing ambiguity surfaced at 3a has an answer in the 3b output. Cases the designer cannot answer without user input bubble up to a user gate, not a silent guess. Fidelity = answered questions, not pixel count.

### Reiterate protocol

The user may re-enter the pipeline at any prior stage after meta-review. On meta-reviewer issue list, two user paths:

- **(a) Fix + re-dispatch.** User picks issues to fix + names the stage to reiterate. That stage reruns with the issue list as added input. Downstream stages rerun from that point.
- **(b) Ship with named exception.** User green-lights ship ignoring named issues. Each exception carries a one-line reason in the session README under §Exceptions shipped. Meta-reviewer cannot override (a) into (b). Only the user can.

Reiteration cannot originate from a role. Meta-reviewer flags; role-to-role handoff does not skip stages. The user is the only loop trigger.

### Meta-reviewer rubric

Stage 7 meta-reviewer fails a build when ANY rubric item is unanswered or contradicted. Items:

1. **Every analyst open-question has an answer visible in the final UI.** Questions without UI answers bubble up for user ruling; they do not silently pass.
2. **Every direction-doc pattern named at stage 2 has an implementation in the built prototype.** Pattern without impl = stage-3b or stage-5 gap.
3. **Every consistency-jobstory guess (stage 6a) either matches the analyst's stated intent OR names a real ambiguity.** Guesses that do not track intent are UX failures, not OK-reads.
4. **Zero off-inventory components.** Every class resolves to `manifesto.md § Components`. User-agreed exceptions allowed only if recorded in direction doc + CHANGELOG.
5. **Zero AI-tells.** Full `voice.md` §No AI tells inventory applies. Evidence source: stage 6c voice reviewer's flag list. Each flag must be either fixed in copy or stamped as a user-approved exception in the direction doc. Unaddressed 6c flags fail this item.
6. **User-agreed exceptions and new components carry paper trail.** Each lives in the direction doc under §Exceptions with reason + user stamp.

Meta-reviewer rejects "it's fine" replies. A rubric item is either answered with evidence (file:line citation) or left open. Open items fail the build until the user acts via reiterate protocol.

### Dumb-reviewer character

Every Haiku "dumb" reviewer operates in character as **Steve Jobs himself**. Expects self-evident design understandable in 0.2 seconds just by looking. No thinking, no hover-to-learn, no tooltip archaeology. Anything that takes a moment to parse is a defect. Does not excuse complexity. Does not justify. Does not read role briefs or direction docs to fill gaps.

**Output shape, five sections, every dumb-reviewer invocation:**

1. **What is on screen.** Literal description. "Three cards stacked. Top one has a dark title and a checkmark. Middle one has an input with grey text. Bottom one is empty."
2. **What looks doable.** Guessed affordances from visuals alone. "Top card looks clickable. The input looks typable. The bottom card seems dead."
3. **What this is for, the guess at job and flow.** Best guess at what the user is doing here, which step of which flow, what likely comes next, from the pixels alone. "Feels like someone is writing a strategy brief. Probably near the start. Click the button, probably research kicks off. Maybe."
4. **What is great.** Self-evident clarity, quiet weight, calm. Specific elements, not general praise.
5. **What could be better.** Anything that pulled the eye wrong, took over 0.2s to parse, looked clickable but was not, looked dead but was alive, read as jargon, needed a label the designer did not provide. Specific, ungenerous.

Reviewer never defers. If a block feels unclear, it says unclear. If a mechanic is hidden, it says hidden. If the job or flow is ambiguous at 0.2s, the guess will reveal the ambiguity. That's the point. Silence on a block = confirmed clarity.

Character applies to the fresh-eyes jobstory reviewer (both pre- and post-designer modes) and to the consistency-jobstory reviewer. Two other Haiku reviewers wear different characters tied to their domain lenses. **Dieter Rams** for consistency-DS (kit-pattern conformance) and **George Orwell** for voice (voice conformance). Both share the strict-when-canon-breaks instinct of Jobs but apply it through their own canonical frame, not the 0.2-second user-clarity frame.

### Role roster

Each role operates in character as a specific person. Gender codes tier: women for Opus + Sonnet (clever roles), men for Haiku (dumb-reviewer roles). Characters are hints for voice, not costume. The skill contract still governs the work.

The kit hosts two pipelines today — `kk-design-system` (this doc) and `kk-charter-system` (sibling at `../../kk-charter-system/`). Five roles are shared. The roster below is the single-source summary across both. The `Pipeline` column reads `kk-ds`, `kk-charter`, or `both`. When stages diverge between pipelines for a shared role (Voice runs at `6c` in kk-ds and `6b` in kk-charter), the `Stage` column carries both labels.

| Pipeline | Stage | Role | Model | Character | Why this person |
|---|---|---|---|---|---|
| both | 1 | Analyst | Sonnet | **Margaret Hamilton** | Apollo software engineer. Coined "software engineering". Decomposition and edge-case rigor refuse to ship systems with unspecified paths. |
| kk-ds | 2 | Design Director | Opus | **Paula Scher** | Pentagram partner behind The Public Theater, Citi, Tiffany, MoMA. Brings multiple directions to the client and commits hard to one so the system can cohere. |
| kk-charter | 2 | Charter Director | Opus | **Tina Brown** | Editor of Tatler at twenty-five, of Vanity Fair at the moment it became Vanity Fair, of The New Yorker. Reshapes a magazine's portfolio of categories before the writers can finish protesting. Names directions, demotes threads pretending to be directions, locks the map. |
| both | 3a + 3c | Fresh-eyes jobstory | Haiku | **Steve Jobs** | 0.2-second clarity bar. Reads as the intended user, ungenerously. |
| kk-ds | 3b | Designer | Sonnet | **Susan Kare** | Original Macintosh icon designer. Drew every state of every icon (trash full and empty, spinning watch, Happy Mac, Sad Mac) in full variant sets at 16×16. |
| kk-charter | 3b (×N) | Charter Writer | Sonnet | **Janet Malcolm** | New Yorker staff writer. *The Journalist and the Murderer*, *In the Freud Archives*. Builds a portrait from documentary evidence, cites every claim, refuses gloss and the editorial *we*. One instance per direction, fan-out parallel. |
| kk-ds | 4 | DS Manager | Sonnet | **Muriel Cooper** | First art director of MIT Press. Catalogued decades of academic publishing into one visual system without inventing beyond its vocabulary. |
| kk-charter | 4 | Portfolio Manager | Sonnet | **Indra Nooyi** | PepsiCo CEO. *Performance with Purpose*. Pulled the company's portfolio (Pepsi, Frito-Lay, Quaker, Tropicana, Gatorade) into one ranking with explicit cross-direction trade-offs. Reads every charter, maps dates, names conflicts, sequences. |
| kk-ds | 5 | Design Engineer | Sonnet | **Sara Soueidan** | Front-end craft writer. Ships accessible components piece by piece, state by state, honors the platform before reaching for abstractions. |
| kk-ds | 6a | Consistency, jobstory | Haiku | **Steve Jobs** | Same 0.2s bar as 3a/3c. Read cold, report what a Steve Jobs reads upfront. |
| kk-charter | 6a | Consistency, charter | Haiku | **Jan Tschichold** | Penguin Books typographer. *Penguin Composition Rules* (1947). Rebuilt 500 titles under one compositional grammar so no two books contradicted each other on type, spacing, or page geometry. Same craft on charter prose: walk the inventory, off-canon = fail. |
| kk-ds | 6b | Consistency, DS | Haiku | **Dieter Rams** | Braun designer. Ten Principles of Good Design. Strict kit-pattern conformance, flags inventory drift, calls off-grid spacing on sight. |
| both | 6c (kk-ds) / 6b (kk-charter) | Voice | Haiku | **George Orwell** | "Politics and the English Language" author. Six rules for clear prose, ancestor of the AI-tells inventory. Names jargon, cuts padding, refuses vague abstraction. |
| both | 7 | Meta-reviewer | Opus | **Erika Hall** | Mule Design co-founder. *Just Enough Research*, *Conversational Design*. Evidence-gated critique that rejects "it's fine". The design is finished when the last reason to remove something is gone. |
| both | meta | Meta-retro | Opus | **Joan Didion** | Essayist. *Slouching Towards Bethlehem*, *The White Album*. Observes the pattern that was there all along and names it without flinching. |
| kk-ds | post | Pattern discoverer | Sonnet | **Jina Anne** | Built Salesforce Lightning Design System. Founded the Design Systems Conference. Co-spec'd the W3C Design Tokens work. Cataloguer whose craft is naming and inventorying systems, the same craft this role runs on accepted prototypes. |
| kk-ds | any | Maintainer | Sonnet | **Rachel Andrew** | CSS Grid spec co-editor at W3C. Former Smashing Magazine editor-in-chief. Ships spec revisions with bundle discipline, semver by blast radius, tag and push before close. |

Steve Jobs appears twice in kk-ds (3a/3c and 6a) deliberately. Same dumb-reader character at different stages, not two different men. Dieter Rams (consistency-DS) and Jan Tschichold (consistency-charter) are separate Haiku characters because each owns a distinct canon lens — Rams flags off-pattern UI, Tschichold flags off-canon prose.

Each role's own `SKILL.md` repeats the character in frontmatter (`character: {name, voice}`) and expands on the match in a §Character body section. The roster above is the single-source summary; the skill file carries the operating reference the agent reads at invocation.

### Agent communication protocol

Every role skill speaks to the user in caveman register by default. Rationale: agent conversation bloats with filler that `voice.md` already forbids in rendered documents; the pipeline needs the same compression on the conversation layer so each stage's summary reads as fact, not pitch.

Rules:

- Drop articles (a / an / the), filler (just, really, basically, actually, simply), pleasantries (sure, certainly, happy to), hedging.
- Fragments OK. Short synonyms. Technical terms stay exact.
- Unchanged surfaces, never compressed: code blocks, file paths, URLs, error strings, frontmatter keys and values, blockquoted raw user input.
- Structured design artefacts, never compressed: ASCII flow mockups, JSON component trees, hand-off tables, rubric verdicts. Designer outputs render untouched.
- Auto-clarity carve-out: drop caveman for multi-step sequences where fragment order risks misread, destructive confirmations, or when the human asks for clarification. Resume after the clear part.

Override by user:

- `stop caveman`. Revert to full prose for the rest of the session.
- `/caveman lite` or `/caveman ultra`. Switch intensity.

Scope boundary: this protocol governs agent-to-user conversation. `voice.md` governs rendered document prose and UI labels. When writing to an artefact (documentation file, prototype copy, signed deliverable), `voice.md` wins. When replying in conversation, this protocol wins. Source inspiration: [JuliusBrussee/caveman](https://github.com/JuliusBrussee/caveman).

### Documentation contract

Every stage, as its final step, writes a documentation file:

```
documentation/<session>/NN-<role>.md
```

Each file carries frontmatter:

```yaml
---
session: <session id>
stage: <stage number>
role: <role name>
input: <prior stage output path>
output: <summary of what this stage produced>
gate: <gate result>
---
```

Body carries: raw user input verbatim where the stage received one, agent output summary, reasoning for non-obvious decisions, gate result. Artifact pointers, not copies. Build files live in their repo location, the doc links.

`README.md` is maintained by the analyst at stage 1, appended by each subsequent stage. The README's §Exceptions shipped section is created on first use when the user ships via reiterate path (b).

### Vertical slice rule

High-fidelity prototype covers one page or one flow per pass. Pattern: `page → flow → next page → flow`. A session that tries to cover the whole product in one run is bloated and untestable. Halt it and split.

### Parallel spawning

Three parallel moments in pipeline-v3:

- **Stage 3a, 3b, 3c.** N instances per stage, one per pattern block named in the direction doc. All three substages run parallel across patterns; each pattern's 3a → 3b → 3c loop is sequential within that pattern.
- **Stage 6a + 6b + 6c.** Three cold-read reviewers, in parallel on the same built prototype. Each has its own canonical frame (jobstory clarity, kit-pattern conformance, voice conformance) and carries its own character.

Spawning owner:

- **3a** spawned by the design director at the end of stage 2 (one per pattern).
- **3b** spawned by each 3a instance on pass (or by the design director after consolidating 3a outputs, implementation detail).
- **3c** spawned by each 3b instance on completion.
- **6a + 6b + 6c** spawned by the design engineer at stage-5 ship.

Wall-clock cost stays at one stage per phase, not N.

### Entry point matching — the recipe map

Every kit-touching session names its pipeline recipe before code touches disk. The default is the full walk; deviations need a stamp. Architectural impact picks the recipe, not diff size.

**Default — full walk.** Stages 1 → 2 → 3a/b/c × N → 4 → 5 → 6a + 6b + 6c → 7. New pages, new flows, new components, new conventions, anything that touches structural behavior. The canonical path.

**Docs / canon / maintainer rework.** The 1.3.0 content-architecture session shape. Touches canon `.md` files (`manifesto.md`, `canon/components.md`, `canon/patterns.md`, `canon/voice.md`, `pipeline/pipeline.md`, `pipeline/protocols.md`) or maintainer-facing structure (folder layout, file moves, conventions). Pattern blocks are doc surfaces, not UI features. Stage 6a skipped per kit-internal review adaptation. Stages 1 → 2 → 3a/b/c × N → 4 → 5 → 6b + 6c → 7. Mid-build reiterate after stage 7 FAIL is expected.

**Kit refactor (like the kit.js extraction).** Stage 1 + stage 5 in DS-engineer mode + stage 6b + stage 7. Pattern design phase skipped; the direction doc §Exceptions block is populated directly by the human.

**New component in an existing page.** Stages 2 to 7.

**Typo or copy tweak.** Stage 3b only for the affected pattern. Stage 6a + 6b + 7 follow if the copy lands in the shipped prototype; otherwise stop at 3b.

**Haiku short-fix.** Single CSS rule edit, single content tweak, padding or value adjustment. NO new component, NO new token, NO new convention, NO canon prose rewrite. Single Haiku agent ships fix + commit + tag. No 6b / 6c / 7 review loop. v1.3.1 and v1.3.2 used this path. When unsure between Haiku-path and full walk, default to full walk.

**Retro.** Meta only.

Entry point is declared at session start and recorded in `documentation/<session>/README.md`. Diff size is a misleading signal — a small CSS edit can be architecturally wrong (the 1.3.3 `:is()` broadening was three lines and got reverted at first sight). When a change touches a canon file, modifies kit JS behavior, adds or removes a CSS class, or introduces a new pattern or rule, walk the canon path.

### Post-pipeline pattern discovery

Pattern discovery sits outside the eight-stage walk. It is a post-pipeline pass, triggered by the `--accepted` suffix on a prototype folder. `kk-role-pattern-discoverer` runs once per accepted prototype against `demos/<slug>--accepted/`, slices qualifying compositions to `demos/<slug>--accepted/patterns/<pattern-slug>.html`, and appends rows to the registry table inside `skills/kk-design-system/canon/patterns.md` for anything not already catalogued. First-accepted wins on cross-prototype dedup. Repeat patterns add a usage citation to the existing entry rather than creating a second one. The discoverer never edits canon.

### Kit-internal review adaptation

Pipeline-v3 review stages were designed for product-shaped artifacts. Kit-internal artifacts (`fundamental`, a slimmed `index.html`, future in-repo docs) need an adapted sweep because there is no analyst jobstory for the cold read at 6a to gate against.

- **Stage 6a, consistency jobstory:** skipped for kit-internal artifacts. No analyst jobstory exists, so the 0.2-second cold read has nothing to compare against at stage 7.
- **Stage 6b, consistency DS:** runs. Kit-pattern conformance applies to anything using the kit.
- **Stage 6c, voice:** runs. Voice audit applies to any visible prose.
- **Stage 7, meta-reviewer:** runs on an adjusted rubric. Drop the 6a-vs-analyst comparison item. Add an artifact-specific completeness item, stated in the session README at walk start (for `fundamental`: "every atom present, every element present, no catalog ceremony retained").

The adaptation is scope-triggered. A session opened against a kit-internal artifact declares the adapted sweep in `documentation/<session>/README.md`; product-shaped sessions run the unadjusted pipeline.

## Failure mode to watch for

Agents like to patch. When stage 7 fails, the tempting fix is to tweak the built output. That is how drift enters. Reiterate protocol names the stage that owns each failure. Return there. Rebuild from kit parts, not from the broken draft.

Second failure mode: stage 3c passing with hollow answers. "Answered" means the designer's 03b has a visible answer in ASCII or copy, not a sentence saying "this is handled". Reviewer at 3c enforces answer shape. A deflection marks unanswered and returns.

## Documentation contract

Shared by every role skill in the pipeline. Each role's `SKILL.md` references this section for output shape so the contract stays in one place.

### Two artifacts per stage

Every role produces two artifacts, both mandatory.

1. **Conversation return.** A short structured message the human reads in under a minute.
2. **Disk artifact.** A file under `documentation/<session>/NN-<role>.md` that preserves raw user input plus the role's output for retros.

A role has not delivered until both exist.

### Session slug

At the top of stage 1 the analyst coins the session slug. Format: `YYYY-MM-DD-<short-product-slug>`. Example: `2026-04-22-wealthy-alpha`. Every stage in the same session writes into `documentation/<slug>/`.

### Disk artifact frontmatter spec

Every `NN-<role>.md` file starts with this block:

```yaml
---
session: <session slug>
stage: <stage number 1..10, or "retro">
role: <role name, e.g. analyst, art-director, frontend-engineer>
input: <path or short description of this stage's input>
output: <one-line summary of what the stage produced>
gate: <gate result, e.g. "user approved", "passed to stage 2", "failed - returned to stage 4">
---
```

Keep values short. One line each. Anything longer lives in the body.

### Disk artifact body structure

Every body starts with a one-sentence description of what the stage did, then these sections in order:

1. `## Raw input`. Verbatim user message in a blockquote. If the stage received a file, reference the path and include a short digest. If the stage received prior-stage output, point to that file.
2. `## <role-specific section>`. The role's actual output. What sections exist here depends on the role; each role skill documents its own set.
3. `## Gate`. Pass or fail. On fail, name which earlier stage owns the failure.
4. `## Hand-off`. Which stage runs next, and what file path it will read.

### Conversation return shape

Short enough to fit in one screen. Markdown, no preamble. Sections match the role's purpose but stay tight:

```
# <Role> — <session slug>

## <section>
<content>

## <section>
<content>

## <section>
<content>
```

A role that cannot fit its return in one screen is returning too much. Split into multiple turns or move detail to the disk artifact.

### README.md

The analyst creates `documentation/<session>/README.md` at stage 1. Each subsequent stage appends to the file index at the bottom.

Initial README:

```markdown
# Session — <product slug>

Date: <YYYY-MM-DD>
Owner: <user name>
Product: <one line>
Entry point: <stage range from analyst>
Kit version: <version>

## Outcome
<to be filled at ship>

## File index

| File | Stage | Role | What |
|---|---|---|---|
| [00-brief.md](./00-brief.md) | 0 | user | Original ask |
| [01-analyst.md](./01-analyst.md) | 1 | analyst | Decomposition |
```

Each subsequent stage adds its own row.

### Pointers, not copies

Build artifacts (HTML, CSS, JS, Figma files) live in their own repo locations. The documentation references them with relative paths plus a one-line digest. Copying bloats the folder and drifts when the code changes.

### Raw input verbatim

The raw input section of every artifact preserves the user's message exactly as typed. Do not summarize, restyle, or translate. A retro reconstructs what the user actually said. The model's interpretation of their words lives in the role sections below, clearly separated.

### Archive, do not delete

Rejected options (unused directions from stage 2, unused concepts from stage 3, unused hand-offs from stage 7) stay in the session folder. Never delete. A retro often learns more from the rejected option than the chosen one.
